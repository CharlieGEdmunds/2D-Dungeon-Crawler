import pygame as py
from pygame.locals import *

class arrow():
    def __init__(self,x,y,speed,fired):
        self.speed = speed
        self.rect = py.Rect(x,y + 1,16,16)
        self.fired = fired

    