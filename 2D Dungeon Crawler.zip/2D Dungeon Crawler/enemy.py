import math
import pygame as py
from pygame.locals import *
from bullet import *
import random

class enemy():
    def __init__(self,grid,enemyType):
        self.grid = grid
        self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,16,16)
        self.enemyType = enemyType
        self.fireTimer = 0
        
        self.bulletRect = py.Rect(0,0,16,16)
        self.newBulletPosition = py.math.Vector2(self.rect.x,self.rect.y)
        self.newPosition = py.math.Vector2(self.rect.x,self.rect.y)
        self.position = py.math.Vector2(self.rect.x,self.rect.y)
        self.hitdelay = 0
        self.hitstun = 0
        self.hitstunAnimation = False
        self.hitstunAnimationTimer = 0
        self.bulletList1 = []
        self.bulletList2 = []
        self.testBulletList1 = []
        self.bossBulletList = []
        self.bossBulletList2 = []
        self.isDamaged = False
        self.currentBatTimer = 0
        self.currentRadioactiveBatTimer = 0
        self.currentSpaceBatTimer = 0
        self.currentBlueSlimeTimer = 0
        self.currentGreenSlimeTimer = 0
        self.currentRedSlimeTimer = 0
        self.currentAkanameMoveTimer = 0
        self.currentAkanameAttackTimer = 0
        self.currentBrainMoleMoveTimer = 0
        self.currentBrainMoleAttackTimer = 0
        self.currentFishfolkMoveSprite = 0
        self.currentFishfolkMoveTimer = 0
        self.currentFishfolkAttackSprite = 0
        self.currentFishfolkAttackTimer = 0
        self.currentStoneIdleTimer = 0
        self.currentStoneGlowTimer = 0
        self.currentStoneRangeTimer = 0
        self.currentStoneImmuneTimer = 0
        self.currentStoneMeleeTimer = 0
        self.currentStoneLaserTimer = 0
        self.currentStoneArmourTimer = 0
        self.currentStoneAppearTimer = 0
        self.laserAngle = 0
        self.bossEnterTime = 0
        self.bossEnterBool = False
        self.splitBool = False
        self.splitCount = 0
        self.bulletCollided = False
        self.homingBool = False
        self.homingCount = 0
        self.enemyGroup = "none"

        if self.enemyType == 1:
            slimeOrBat = random.randint(1,2)
            if slimeOrBat == 1:
                self.speed = 0.2
                self.health = 5
                self.bulletSpeed = 3
                self.shotDelay = 6000
                self.shotDamage = 5
                self.armour = 0.3
                self.shotImage = py.image.load("batShot.png")
                self.enemyGroup = "bat"
            else:
                self.speed = 0.67
                self.damage = 3
                self.health = 10
                self.armour = 0.2
                self.enemyGroup = "slime"

        elif self.enemyType == 2:
            slimeOrBat = random.randint(1,2)
            if slimeOrBat == 1:
                self.speed = 0.325
                self.health = 20
                self.shotDelay = 5000
                self.shotDamage = 7
                self.armour = 0.2
                self.shotImage = py.image.load("radioactiveBatShot.png")
                self.enemyGroup = "bat"
            else:
                self.speed = 1
                self.damage = 6
                self.health = 25
                self.armour = 0.25
                self.enemyGroup = "slime"

        elif self.enemyType == 3:
            slimeOrBat = random.randint(1,2)
            if slimeOrBat == 1:
                self.speed = 0.45
                self.health = 30
                self.shotDelay = 4000
                self.shotDamage = 13
                self.armour = 0.1
                self.shotImage = py.image.load("spaceBatShot.png")
                self.enemyGroup = "bat"
            else:
                self.speed = 1.25
                self.damage = 10
                self.health = 35
                self.armour = 0.3
                self.enemyGroup = "slime"
        
        elif self.enemyType == 4:
            self.speed = 2
            self.health = 50
            self.armour = 0.4
            self.damage = 10
            self.imageRect = self.rect
            self.currentImageHeight = 14
            self.lastImageHeight = 14
            self.facing = "right"
            self.isMoving = True
            self.isAttacking = False
            self.damageRect = self.rect
            self.enemyGroup = "akaname"
        
        elif self.enemyType == 5:
            self.speed = 1.8
            self.health = 75
            self.armour = 0.45
            self.damage = 8
            self.imageRect = self.rect
            self.currentImageHeight = 25
            self.lastImageHeight = 25
            self.facing = "right"
            self.isMoving = True
            self.isAttacking = False
            self.damageRect = self.rect
            self.enemyGroup = "akaname"
        
        elif self.enemyType == 6:
            self.speed = 1.6
            self.health = 80
            self.armour = 0.4
            self.damage = 10
            self.imageRect = self.rect
            self.attackRect = self.rect
            self.currentImageHeight = 23
            self.lastImageHeight = 23
            self.currentImageWidth = 21
            self.lastImageWidth = 21
            self.facing = "right"
            self.isMoving = True
            self.isAttacking = False
            self.isHooking = False
            self.damageRect = self.rect
            self.currentFishfolkHookCooldown = 0
            self.currentFishfolkHookTimer = 5000
            self.enemyGroup = "fishfolk"

            
        elif self.enemyType == 0:
            self.speed = 0
            self.colour = (0,255,0)
            self.health = 0
            self.shotDelay = 99999999999
            self.shotDamage = 0
            self.armour = 0.2
            self.enemyGroup = "dummy"
        
        elif self.enemyType == 100:
            self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,48,48)
            self.speed = 1
            self.health = 200
            self.armour = 0.05
            self.enemyGroup = "boss"
            self.bossIsAppear = True
            self.bossIsIdle = False
            self.bossIsGlowing = False
            self.bossIsRange = False
            self.bossIsImmune = False
            self.bossIsMelee = False
            self.bossIsLaser = False
            self.bossIsArmour = False
            self.shotImage = py.image.load("spaceBatShot.png")
            self.shotDamage = 10
            self.bossAttackCooldown = 0
            self.randomAttack = 0
            self.currentAttackTimer = 0
            self.bossAttack2Cooldown = 0
            self.boss2FireStart = False
            self.bossFire3Start = False
            self.bossFire4Count = 0
            self.bossFire4Start = False
            self.bossFire4Timer = 0

        elif self.enemyType == 10:
            self.speed = 1
            self.health = 30
            self.armour = 0.05
            self.shotDelay = 4000
            self.shotDamage = 10
            self.shotImage = py.image.load("batShot.png")
            self.enemyGroup = "test"

    def batAI(self,player,collision):
        self.collisionCheckX = False
        self.collisionCheckY = False
        player_pos = player.topleft
        direction = player_pos - self.newPosition
        if direction[0] != 0 or direction[1] != 0:
            velocity = direction.normalize() * self.speed
        else:
            velocity = py.math.Vector2(0,0)

        self.newPosition.y += velocity[1]

        self.newYRect = py.Rect(self.rect.x,self.newPosition[1],16,16)

        for c in collision:
            if self.newYRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                self.collisionCheckY = True
            elif self.newYRect.colliderect(c.rect) and c.index == "door":
                self.NextLevel = True
        
        self.newPosition.x += velocity[0]
        self.newXRect = py.Rect(self.newPosition[0],self.rect.y,16,16)
        for c in collision:
            if self.newXRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                self.collisionCheckX = True
            elif self.newXRect.colliderect(c.rect) and c.index == "door":
                self.NextLevel = True

        if direction.length() > 150:
            if self.speed < 0:
                self.speed = -self.speed
            if not self.collisionCheckX and not self.hitstunAnimation:
                self.rect.x = self.newPosition[0]
            else:
                self.newPosition[0] -= velocity[0]
            
            if not self.collisionCheckY and not self.hitstunAnimation:
                self.rect.y = self.newPosition[1]
            else:
                self.newPosition[1] -= velocity[1]
        
        else:
            if self.speed > 0:
                self.speed = -self.speed
            if not self.collisionCheckX and not self.hitstunAnimation:
                self.rect.x = self.newPosition[0]
            else:
                self.newPosition[0] -= velocity[0]
            
            if not self.collisionCheckY and not self.hitstunAnimation:
                self.rect.y = self.newPosition[1]
            else:
                self.newPosition[1] -= velocity[1]
      
    def slimeAI(self,player,collision):
        self.collisionCheckX = False
        self.collisionCheckY = False
        player_pos = player.topleft
        direction = player_pos - self.newPosition
        if direction[0] != 0 or direction[1] != 0:
            velocity = direction.normalize() * self.speed
        else:
            velocity = py.math.Vector2(0,0)

        self.newPosition.y += velocity[1]

        self.newYRect = py.Rect(self.rect.x,self.newPosition[1],16,16)

        for c in collision:
            if self.newYRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                self.collisionCheckY = True
            elif self.newYRect.colliderect(c.rect) and c.index == "door":
                self.NextLevel = True
        
        self.newPosition.x += velocity[0]
        
        self.newXRect = py.Rect(self.newPosition[0],self.rect.y,16,16)
        for c in collision:
            if self.newXRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                self.collisionCheckX = True
            elif self.newXRect.colliderect(c.rect) and c.index == "door":
                self.NextLevel = True

        if self.speed < 0:
            self.speed = -self.speed
        if not self.collisionCheckX and not self.hitstunAnimation:
            self.rect.x = self.newPosition[0]
        else:
            self.newPosition[0] -= velocity[0]
        
        if not self.collisionCheckY and not self.hitstunAnimation:
            self.rect.y = self.newPosition[1]
        else:
            self.newPosition[1] -= velocity[1]
    
    def akanameAI(self,player,collision):
        self.collisionCheckX = False
        self.collisionCheckY = False
        player_pos = player.topleft
        direction = player_pos - self.newPosition
        if direction[0] > -15 and direction[0] < 15 and direction[1] > -8 and direction[1] < 8:
            self.isMoving = False
            self.isAttacking = True
        
        if direction[0] >= 0:
            self.facing = "right"
        else:
            self.facing = "left"
        
        if self.isMoving:
            if direction[0] != 0 or direction[1] != 0:
                velocity = direction.normalize() * self.speed
            else:
                velocity = py.math.Vector2(0,0)

            self.newPosition.y += velocity[1]

            self.newYRect = py.Rect(self.rect.x,self.newPosition[1],16,16)

            for c in collision:
                if self.newYRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                    self.collisionCheckY = True
                elif self.newYRect.colliderect(c.rect) and c.index == "door":
                    self.NextLevel = True
            
            self.newPosition.x += velocity[0]
            self.newXRect = py.Rect(self.newPosition[0],self.rect.y,16,16)
            for c in collision:
                if self.newXRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                    self.collisionCheckX = True
                elif self.newXRect.colliderect(c.rect) and c.index == "door":
                    self.NextLevel = True

            if self.speed < 0:
                self.speed = -self.speed
            if not self.collisionCheckX and not self.hitstunAnimation:
                self.rect.x = self.newPosition[0]
            else:
                self.newPosition[0] -= velocity[0]
            
            if not self.collisionCheckY and not self.hitstunAnimation:
                self.rect.y = self.newPosition[1]
            else:
                self.newPosition[1] -= velocity[1]
            
            self.imageRect = self.rect

    def fishfolkAI(self,player,collision):
        self.collisionCheckX = False
        self.collisionCheckY = False
        player_pos = player.topleft
        direction = player_pos - self.newPosition

        if py.time.get_ticks() > self.currentFishfolkHookCooldown + self.currentFishfolkHookTimer:
            if direction[0] > -40 and direction[0] < 40 and direction[1] > -10 and direction[1] < 10:
                self.isAttacking = False
                self.isMoving = False
                self.isHooking = True
                self.currentFishfolkHookCooldown = py.time.get_ticks()

        elif direction[0] > -25 and direction[0] < 25 and direction[1] > -8 and direction[1] < 8 and not self.isHooking:
            self.isMoving = False
            self.isAttacking = True
        
        if direction[0] >= 0:
            self.facing = "right"
        else:
            self.facing = "left"
        
        if self.isMoving:
            if direction[0] != 0 or direction[1] != 0:
                velocity = direction.normalize() * self.speed
            else:
                velocity = py.math.Vector2(0,0)

            self.newPosition.y += velocity[1]

            self.newYRect = py.Rect(self.rect.x,self.newPosition[1],16,16)

            for c in collision:
                if self.newYRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                    self.collisionCheckY = True
                elif self.newYRect.colliderect(c.rect) and c.index == "door":
                    self.NextLevel = True
            
            self.newPosition.x += velocity[0]
            self.newXRect = py.Rect(self.newPosition[0],self.rect.y,16,16)
            for c in collision:
                if self.newXRect.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23:
                    self.collisionCheckX = True
                elif self.newXRect.colliderect(c.rect) and c.index == "door":
                    self.NextLevel = True

            if self.speed < 0:
                self.speed = -self.speed
            if not self.collisionCheckX and not self.hitstunAnimation:
                self.rect.x = self.newPosition[0]
            else:
                self.newPosition[0] -= velocity[0]
            
            if not self.collisionCheckY and not self.hitstunAnimation:
                self.rect.y = self.newPosition[1]
            else:
                self.newPosition[1] -= velocity[1]
            
            self.imageRect = self.rect

    def bossAI(self,player):
        if not self.bossEnterBool:
            self.bossEnterTime = py.time.get_ticks()
            self.bossEnterBool = True
            player.isDamaged = True
        if py.time.get_ticks() > self.bossEnterTime + 1400:
            self.bossIsAppear = False
            self.bossIsGlowing = True
            if py.time.get_ticks() > self.bossAttackCooldown + self.currentAttackTimer:
                self.bossBulletList = []
                self.splitBool = False
                self.homingBool = False
                self.splitCount = 0
                self.homingCount = 0
                self.randomAttack = random.randint(1,3)
                if self.randomAttack == 1:
                    self.bossFire1(player)
                    self.currentAttackTimer = 3000
                elif self.randomAttack == 2:
                    self.bossFire2(player)
                    self.boss2FireStart = True
                    self.currentAttackTimer = 7500
                elif self.randomAttack == 3:
                    self.bossFire3Start = True
                    self.bossFire3(player)
                    self.currentAttackTimer = 7500
                elif self.randomAttack == 4:
                    self.bossFire4Start = True
                    self.currentAttackTimer = 7500
                self.bossAttackCooldown = py.time.get_ticks()

        if self.bossFire4Start:
            self.bossFire4(player)

    def hit(self,player):
        if py.time.get_ticks() > self.hitdelay + 200:
            if self.rect.colliderect(player.rect):
                player.hit(self.damage)
                self.hitdelay = py.time.get_ticks()

    def damaged(self,damage,armourPen):
        self.isDamaged = True
        self.damageReduced = 1-self.armour+armourPen
        if self.damageReduced > 1:
            self.damageReduced = 1
        self.health -= (damage * self.damageReduced)
        self.hitstun = py.time.get_ticks()
        self.hitstunAnimation = True
        self.hitstunAnimationTimer = py.time.get_ticks()
    
    def fire(self,player):
        if self.enemyType == 1:
            self.bulletList1.append(bullet(self.rect.x,self.rect.y,player.rect.x,player.rect.y,3,6,self.rect,0,0))
        elif self.enemyType == 2:
            self.bulletList1.append(bullet(self.rect.x,self.rect.y,player.rect.x,player.rect.y,3,10,self.rect,0,0))
        elif self.enemyType == 3:
            self.bulletList1.append(bullet(self.rect.x,self.rect.y,player.rect.x,player.rect.y,3,16,self.rect,0,0))
        elif self.enemyType == 10:
            self.testBulletList1.append(bullet(self.rect.x,self.rect.y,player.rect.x,player.rect.y,3,16,self.rect,0,0))

    def bossFire1(self,player):
        self.bossBulletList.append(bullet(self.rect.x + 16,self.rect.y,player.rect.x,player.rect.y,8,16,self.rect,0,0))
    
    def bossFire2(self,player):
        for i in range(1,5):
            self.bossBulletList.append(bullet(self.rect.x + 16,self.rect.y,player.rect.x,player.rect.y,1,16,self.rect,i,0))
    
    def split(self,player,bulletRect):
        for i in range(1,5):
            self.bossBulletList.append(bullet(bulletRect.x,bulletRect.y,player.rect.x,player.rect.y,7,16,bulletRect,i,0))
    
    def bossFire3(self,player):
        for i in range(1,7):
            self.bossBulletList.append(bullet(self.rect.x + 8,self.rect.y + 8,player.rect.x,player.rect.y,3,16,self.rect,i,0))
    
    def bossFire4(self,player):
        if py.time.get_ticks() > self.bossFire4Timer + 500:
            for i in range(1,5):
                if self.bossFire4Count <= 10:
                    if self.bossFire4Count % 2 == 0:
                        self.bossBulletList.append(bullet(self.rect.x + 8,self.rect.y + 8,player.rect.x,player.rect.y,10,16,self.rect,0,i * (pi / 2)))
                    else:
                        self.bossBulletList.append(bullet(self.rect.x + 8,self.rect.y + 8,player.rect.x,player.rect.y,10,16,self.rect,0,pi / 4 + (i * (pi / 2))))
                else:
                    self.bossFire4Start = False
                    self.bossFire4Count = 0
            self.bossFire4Count += 1
            self.bossFire4Timer = py.time.get_ticks()

    def images(self):
        if self.enemyType == 1:
            self.batSprites = []
            self.batSprites.append(py.image.load("Bat1.png"))
            self.batSprites.append(py.image.load("Bat2.png"))
            self.batSprites.append(py.image.load("Bat3.png"))
            self.batSprites.append(py.image.load("Bat4.png"))
            self.currentBatSprite = 0

            self.blueSlimeSprites = []
            self.blueSlimeSprites.append(py.image.load("blueSlime1.png"))
            self.blueSlimeSprites.append(py.image.load("blueSlime2.png"))
            self.blueSlimeSprites.append(py.image.load("blueSlime3.png"))
            self.blueSlimeSprites.append(py.image.load("blueSlime4.png"))
            self.currentBlueSlimeSprite = 0

        if self.enemyType == 2:
            self.radioactiveBatSprites = []
            self.radioactiveBatSprites.append(py.image.load("radioactiveBat1.png"))
            self.radioactiveBatSprites.append(py.image.load("radioactiveBat2.png"))
            self.radioactiveBatSprites.append(py.image.load("radioactiveBat3.png"))
            self.radioactiveBatSprites.append(py.image.load("radioactiveBat4.png"))
            self.currentRadioactiveBatSprite = 0

            self.greenSlimeSprites = []
            self.greenSlimeSprites.append(py.image.load("greenSlime1.png"))
            self.greenSlimeSprites.append(py.image.load("greenSlime2.png"))
            self.greenSlimeSprites.append(py.image.load("greenSlime3.png"))
            self.greenSlimeSprites.append(py.image.load("greenSlime4.png"))
            self.currentGreenSlimeSprite = 0

        if self.enemyType == 3:
            self.spaceBatSprites = []
            self.spaceBatSprites.append(py.image.load("spaceBat1.png"))
            self.spaceBatSprites.append(py.image.load("spaceBat2.png"))
            self.spaceBatSprites.append(py.image.load("spaceBat3.png"))
            self.spaceBatSprites.append(py.image.load("spaceBat4.png"))
            self.currentSpaceBatSprite = 0

            self.redSlimeSprites = []
            self.redSlimeSprites.append(py.image.load("redSlime1.png"))
            self.redSlimeSprites.append(py.image.load("redSlime2.png"))
            self.redSlimeSprites.append(py.image.load("redSlime3.png"))
            self.redSlimeSprites.append(py.image.load("redSlime4.png"))
            self.currentRedSlimeSprite = 0

        if self.enemyType == 4:
            self.akanameMoveSprites = []
            self.akanameMoveSprites.append(py.image.load("akanameMove1.png"))
            self.akanameMoveSprites.append(py.image.load("akanameMove2.png"))
            self.akanameMoveSprites.append(py.image.load("akanameMove3.png"))
            self.akanameMoveSprites.append(py.image.load("akanameMove4.png"))
            self.akanameMoveSprites.append(py.image.load("akanameMove5.png"))
            self.akanameMoveSprites.append(py.image.load("akanameMove6.png"))
            self.akanameMoveSprites.append(py.image.load("akanameMove7.png"))
            self.akanameMoveSprites.append(py.image.load("akanameMove8.png"))
            self.currentAkanameMoveSprite = 0
        
            self.akanameAttackSprites = []
            self.akanameAttackSprites.append(py.image.load("akanameAttack1.png"))
            self.akanameAttackSprites.append(py.image.load("akanameAttack2.png"))
            self.akanameAttackSprites.append(py.image.load("akanameAttack3.png"))
            self.akanameAttackSprites.append(py.image.load("akanameAttack4.png"))
            self.akanameAttackSprites.append(py.image.load("akanameAttack5.png"))
            self.akanameAttackSprites.append(py.image.load("akanameAttack6.png"))
            self.akanameAttackSprites.append(py.image.load("akanameAttack7.png"))
            self.akanameAttackSprites.append(py.image.load("akanameAttack8.png"))
            self.currentAkanameAttackSprite = 0

        if self.enemyType == 5:
            self.brainMoleMoveSprites = []
            self.brainMoleMoveSprites.append(py.image.load("brainMoleMove1.png"))
            self.brainMoleMoveSprites.append(py.image.load("brainMoleMove2.png"))
            self.brainMoleMoveSprites.append(py.image.load("brainMoleMove3.png"))
            self.brainMoleMoveSprites.append(py.image.load("brainMoleMove4.png"))
            self.currentBrainMoleMoveSprite = 0

            self.brainMoleAttackSprites = []
            self.brainMoleAttackSprites.append(py.image.load("brainMoleAttack1.png"))
            self.brainMoleAttackSprites.append(py.image.load("brainMoleAttack2.png"))
            self.brainMoleAttackSprites.append(py.image.load("brainMoleAttack3.png"))
            self.brainMoleAttackSprites.append(py.image.load("brainMoleAttack4.png"))
            self.currentBrainMoleAttackSprite = 0
        
        if self.enemyType == 6:
            self.fishfolkMoveSprites = []
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove1.png"))
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove2.png"))
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove3.png"))
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove4.png"))
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove5.png"))
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove6.png"))
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove7.png"))
            self.fishfolkMoveSprites.append(py.image.load("fishfolkMove8.png"))
            self.currentFishfolkMoveSprite = 0

            self.fishfolkAttackSprites = []
            self.fishfolkAttackSprites.append(py.image.load("fishfolkAttack1.png"))
            self.fishfolkAttackSprites.append(py.image.load("fishfolkAttack2.png"))
            self.fishfolkAttackSprites.append(py.image.load("fishfolkAttack3.png"))
            self.fishfolkAttackSprites.append(py.image.load("fishfolkAttack4.png"))
            self.fishfolkAttackSprites.append(py.image.load("fishfolkAttack5.png"))
            self.fishfolkAttackSprites.append(py.image.load("fishfolkAttack6.png"))
            self.currentFishfolkAttackSprite = 0

            self.fishfolkHookSprites = []
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook1.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook2.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook3.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook4.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook5.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook6.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook7.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook8.png"))
            self.fishfolkHookSprites.append(py.image.load("fishfolkHook9.png"))
            self.currentFishfolkHookSprite = 0

        if self.enemyType == 100:
            self.stoneIdleSprites = []
            self.stoneIdleSprites.append(py.image.load("stoneIdle1.png"))
            self.stoneIdleSprites.append(py.image.load("stoneIdle2.png"))
            self.stoneIdleSprites.append(py.image.load("stoneIdle3.png"))
            self.stoneIdleSprites.append(py.image.load("stoneIdle4.png"))
            self.currentStoneIdleSprite = 0

            self.stoneGlowSprites = []
            self.stoneGlowSprites.append(py.image.load("stoneGlow1.png"))
            self.stoneGlowSprites.append(py.image.load("stoneGlow2.png"))
            self.stoneGlowSprites.append(py.image.load("stoneGlow3.png"))
            self.stoneGlowSprites.append(py.image.load("stoneGlow4.png"))
            self.stoneGlowSprites.append(py.image.load("stoneGlow5.png"))
            self.stoneGlowSprites.append(py.image.load("stoneGlow6.png"))
            self.stoneGlowSprites.append(py.image.load("stoneGlow7.png"))
            self.stoneGlowSprites.append(py.image.load("stoneGlow8.png"))
            self.currentStoneGlowSprite = 0

            self.stoneRangeSprites = []
            self.stoneRangeSprites.append(py.image.load("stoneRange1.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange2.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange3.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange4.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange5.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange6.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange7.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange8.png"))
            self.stoneRangeSprites.append(py.image.load("stoneRange9.png"))
            self.currentStoneRangeSprite = 0

            self.stoneImmuneSprites = []
            self.stoneImmuneSprites.append(py.image.load("stoneImmune1.png"))
            self.stoneImmuneSprites.append(py.image.load("stoneImmune2.png"))
            self.stoneImmuneSprites.append(py.image.load("stoneImmune3.png"))
            self.stoneImmuneSprites.append(py.image.load("stoneImmune4.png"))
            self.stoneImmuneSprites.append(py.image.load("stoneImmune5.png"))
            self.stoneImmuneSprites.append(py.image.load("stoneImmune6.png"))
            self.stoneImmuneSprites.append(py.image.load("stoneImmune7.png"))
            self.stoneImmuneSprites.append(py.image.load("stoneImmune8.png"))
            self.currentStoneImmuneSprite = 0

            self.stoneMeleeSprites = []
            self.stoneMeleeSprites.append(py.image.load("stoneMelee1.png"))
            self.stoneMeleeSprites.append(py.image.load("stoneMelee2.png"))
            self.stoneMeleeSprites.append(py.image.load("stoneMelee3.png"))
            self.stoneMeleeSprites.append(py.image.load("stoneMelee4.png"))
            self.stoneMeleeSprites.append(py.image.load("stoneMelee5.png"))
            self.stoneMeleeSprites.append(py.image.load("stoneMelee6.png"))
            self.stoneMeleeSprites.append(py.image.load("stoneMelee7.png"))
            self.currentStoneMeleeSprite = 0
        
            self.stoneLaserSprites = []
            self.stoneLaserSprites.append(py.image.load("stoneLaser1.png"))
            self.stoneLaserSprites.append(py.image.load("stoneLaser2.png"))
            self.stoneLaserSprites.append(py.image.load("stoneLaser3.png"))
            self.stoneLaserSprites.append(py.image.load("stoneLaser4.png"))
            self.stoneLaserSprites.append(py.image.load("stoneLaser5.png"))
            self.stoneLaserSprites.append(py.image.load("stoneLaser6.png"))
            self.stoneLaserSprites.append(py.image.load("stoneLaser7.png"))
            self.currentStoneLaserSprite = 0

            self.stoneArmourSprites = []
            self.stoneArmourSprites.append(py.image.load("stoneArmour1.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour2.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour3.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour4.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour5.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour6.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour7.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour8.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour9.png"))
            self.stoneArmourSprites.append(py.image.load("stoneArmour10.png"))
            self.currentStoneArmourSprite = 0

            self.stoneAppearSprites = []
            self.stoneAppearSprites.append(py.image.load("stoneAppear1.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear2.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear3.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear4.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear5.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear6.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear7.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear8.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear9.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear10.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear11.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear12.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear13.png"))
            self.stoneAppearSprites.append(py.image.load("stoneAppear14.png"))
            self.currentStoneAppearSprite = 0

            self.laser = py.image.load("laser.png")
    
    def updateBat(self):
        if py.time.get_ticks() > self.currentBatTimer + 100:
            self.currentBatSprite += 1
            if self.currentBatSprite >= len(self.batSprites):
                self.currentBatSprite = 0
            
            self.batImage = self.batSprites[self.currentBatSprite]
            self.currentBatTimer = py.time.get_ticks()
    
    def updateRadioactiveBat(self):
        if py.time.get_ticks() > self.currentRadioactiveBatTimer + 100:
            self.currentRadioactiveBatSprite += 1
            if self.currentRadioactiveBatSprite >= len(self.radioactiveBatSprites):
                self.currentRadioactiveBatSprite = 0
            
            self.radioactiveBatImage = self.radioactiveBatSprites[self.currentRadioactiveBatSprite]
            self.currentRadioactiveBatTimer = py.time.get_ticks()
    
    def updateSpaceBat(self):
        if py.time.get_ticks() > self.currentSpaceBatTimer + 100:
            self.currentSpaceBatSprite += 1
            if self.currentSpaceBatSprite >= len(self.spaceBatSprites):
                self.currentSpaceBatSprite = 0
            
            self.spaceBatImage = self.spaceBatSprites[self.currentSpaceBatSprite]
            self.currentSpaceBatTimer = py.time.get_ticks()

    def updateBlueSlime(self):
        if py.time.get_ticks() > self.currentBlueSlimeTimer + 100:
            self.currentBlueSlimeSprite += 1
            if self.currentBlueSlimeSprite >= len(self.blueSlimeSprites):
                self.currentBlueSlimeSprite = 0
            
            self.blueSlimeImage = self.blueSlimeSprites[self.currentBlueSlimeSprite]
            self.currentBlueSlimeTimer = py.time.get_ticks()
    
    def updateAkanameMove(self):
        if py.time.get_ticks() > self.currentAkanameMoveTimer + 100:
            self.currentAkanameMoveSprite += 1
            if self.currentAkanameMoveSprite >= len(self.akanameMoveSprites):
                self.currentAkanameMoveSprite = 0
            
            self.rect = py.Rect(self.rect.x,self.rect.y,self.akanameMoveSprites[self.currentAkanameMoveSprite].get_width(),self.akanameMoveSprites[self.currentAkanameMoveSprite].get_height())
            
            self.akanameImage = self.akanameMoveSprites[self.currentAkanameMoveSprite]

            if self.facing == "left":
                self.akanameImage = py.transform.flip(self.akanameImage,1,0)
            self.currentAkanameMoveTimer = py.time.get_ticks()
    
    def updateAkanameAttack(self):
        if py.time.get_ticks() > self.currentAkanameAttackTimer + 100:
            self.currentAkanameAttackSprite += 1
            if self.currentAkanameAttackSprite >= len(self.akanameAttackSprites):
                self.currentAkanameAttackSprite = 0
                self.isAttacking = False
                self.isMoving = True

            self.rect = py.Rect(self.rect.x,self.rect.y,self.akanameMoveSprites[self.currentAkanameMoveSprite].get_width(),self.akanameMoveSprites[self.currentAkanameMoveSprite].get_height())

            self.imageRect = self.rect
            self.currentImageHeight = self.akanameAttackSprites[self.currentAkanameAttackSprite].get_height()

            self.imageRect.y -= self.currentImageHeight - self.lastImageHeight
            self.lastImageHeight = self.akanameAttackSprites[self.currentAkanameAttackSprite].get_height()

            self.damageRect = self.akanameAttackSprites[self.currentAkanameAttackSprite].get_rect()
            self.damageRect.x += self.rect.x
            self.damageRect.y += self.rect.y
            
            self.akanameImage = self.akanameAttackSprites[self.currentAkanameAttackSprite]
            if self.facing == "left":
                self.akanameImage = py.transform.flip(self.akanameImage,1,0)
            self.currentAkanameAttackTimer = py.time.get_ticks()
    
    def updateBrainMoleMove(self):
        if py.time.get_ticks() > self.currentBrainMoleMoveTimer + 100:
            self.currentBrainMoleMoveSprite += 1
            if self.currentBrainMoleMoveSprite >= len(self.brainMoleMoveSprites):
                self.currentBrainMoleMoveSprite = 0
            
            self.rect = py.Rect(self.rect.x,self.rect.y,self.brainMoleMoveSprites[self.currentBrainMoleMoveSprite].get_width(),self.brainMoleMoveSprites[self.currentBrainMoleMoveSprite].get_height())
            
            self.brainMoleImage = self.brainMoleMoveSprites[self.currentBrainMoleMoveSprite]
            if self.facing == "left":
                self.brainMoleImage = py.transform.flip(self.brainMoleImage,1,0)
            self.currentBrainMoleMoveTimer = py.time.get_ticks()
    
    def updateBrainMoleAttack(self):
        if py.time.get_ticks() > self.currentBrainMoleAttackTimer + 100:
            self.currentBrainMoleAttackSprite += 1
            if self.currentBrainMoleAttackSprite >= len(self.brainMoleAttackSprites):
                self.currentBrainMoleAttackSprite = 0
                self.isAttacking = False
                self.isMoving = True
            
            self.rect = py.Rect(self.rect.x,self.rect.y,self.brainMoleAttackSprites[self.currentBrainMoleAttackSprite].get_width(),self.brainMoleAttackSprites[self.currentBrainMoleAttackSprite].get_height())

            self.imageRect = self.rect
            self.currentImageHeight = self.brainMoleAttackSprites[self.currentBrainMoleAttackSprite].get_height()

            self.imageRect.y -= self.currentImageHeight - self.lastImageHeight
            self.lastImageHeight = self.brainMoleAttackSprites[self.currentBrainMoleAttackSprite].get_height()

            self.damageRect = self.brainMoleAttackSprites[self.currentBrainMoleAttackSprite].get_rect()
            self.damageRect.x += self.rect.x
            self.damageRect.y += self.rect.y
            
            self.brainMoleImage = self.brainMoleAttackSprites[self.currentBrainMoleAttackSprite]
            
            if self.facing == "left":
                self.brainMoleImage = py.transform.flip(self.brainMoleImage,1,0)
            self.currentBrainMoleAttackTimer = py.time.get_ticks()
    
    def updateFishfolkMove(self):
        if py.time.get_ticks() > self.currentFishfolkMoveTimer + 100:
            self.currentFishfolkMoveSprite += 1
            if self.currentFishfolkMoveSprite >= len(self.fishfolkMoveSprites):
                self.currentFishfolkMoveSprite = 0
            
            self.rect = py.Rect(self.rect.x,self.rect.y,self.fishfolkMoveSprites[self.currentFishfolkMoveSprite].get_width(),self.fishfolkMoveSprites[self.currentFishfolkMoveSprite].get_height())
            
            self.fishfolkImage = self.fishfolkMoveSprites[self.currentFishfolkMoveSprite]
            if self.facing == "left":
                self.fishfolkImage = py.transform.flip(self.fishfolkImage,1,0)
            self.currentFishfolkMoveTimer = py.time.get_ticks()
    
    def updateFishfolkAttack(self):
        if py.time.get_ticks() > self.currentFishfolkAttackTimer + 100:
            self.currentFishfolkAttackSprite += 1
            if self.currentFishfolkAttackSprite >= len(self.fishfolkAttackSprites):
                self.currentFishfolkAttackSprite = 0
                self.isAttacking = False
                self.isMoving = True

            self.rect = py.Rect(self.rect.x,self.rect.y,self.fishfolkAttackSprites[self.currentFishfolkAttackSprite].get_width(),self.fishfolkAttackSprites[self.currentFishfolkAttackSprite].get_height())

            self.imageRect = self.rect

            self.currentImageHeight = self.fishfolkAttackSprites[self.currentFishfolkAttackSprite].get_height()
            self.imageRect.y -= self.currentImageHeight - self.lastImageHeight
            self.lastImageHeight = self.fishfolkAttackSprites[self.currentFishfolkAttackSprite].get_height()

            self.damageRect = self.fishfolkAttackSprites[self.currentFishfolkAttackSprite].get_rect()
            self.damageRect.x += self.rect.x
            self.damageRect.y += self.rect.y
            
            self.fishfolkImage = self.fishfolkAttackSprites[self.currentFishfolkAttackSprite]
            if self.facing == "left":
                self.currentImageWidth = self.fishfolkAttackSprites[self.currentFishfolkAttackSprite].get_width()
                self.imageRect.x -= self.currentImageWidth - self.lastImageWidth
                self.lastImageWidth = self.fishfolkAttackSprites[self.currentFishfolkAttackSprite].get_width()
                self.fishfolkImage = py.transform.flip(self.fishfolkImage,1,0)
            self.currentFishfolkAttackTimer = py.time.get_ticks()
    
    def updateFishfolkHook(self):
        if py.time.get_ticks() > self.currentFishfolkHookTimer + 100:
            self.currentFishfolkHookSprite += 1
            if self.currentFishfolkHookSprite >= len(self.fishfolkHookSprites):
                self.currentFishfolkHookSprite = 0
                self.isHooking = False
                self.isMoving = True

            self.rect = py.Rect(self.rect.x,self.rect.y,self.fishfolkHookSprites[self.currentFishfolkHookSprite].get_width(),self.fishfolkHookSprites[self.currentFishfolkHookSprite].get_height())

            self.imageRect = self.rect

            self.currentImageHeight = self.fishfolkHookSprites[self.currentFishfolkHookSprite].get_height()
            self.imageRect.y -= self.currentImageHeight - self.lastImageHeight
            self.lastImageHeight = self.fishfolkHookSprites[self.currentFishfolkHookSprite].get_height()

            self.damageRect = self.fishfolkHookSprites[self.currentFishfolkHookSprite].get_rect()
            self.damageRect.x += self.rect.x
            self.damageRect.y += self.rect.y
        
            self.fishfolkImage = self.fishfolkHookSprites[self.currentFishfolkHookSprite]
            if self.facing == "left":
                self.currentImageWidth = self.fishfolkHookSprites[self.currentFishfolkHookSprite].get_width()
                self.imageRect.x -= self.currentImageWidth - self.lastImageWidth
                self.lastImageWidth = self.fishfolkHookSprites[self.currentFishfolkHookSprite].get_width()
                self.fishfolkImage = py.transform.flip(self.fishfolkImage,1,0)
            self.currentFishfolkHookTimer = py.time.get_ticks()

    def updateGreenSlime(self):
        if py.time.get_ticks() > self.currentGreenSlimeTimer + 100:
            self.currentGreenSlimeSprite += 1
            if self.currentGreenSlimeSprite >= len(self.greenSlimeSprites):
                self.currentGreenSlimeSprite = 0
            
            self.greenSlimeImage = self.greenSlimeSprites[self.currentGreenSlimeSprite]
            self.currentGreenSlimeTimer = py.time.get_ticks()
    
    def updateRedSlime(self):
        if py.time.get_ticks() > self.currentRedSlimeTimer + 100:
            self.currentRedSlimeSprite += 1
            if self.currentRedSlimeSprite >= len(self.redSlimeSprites):
                self.currentRedSlimeSprite = 0
            
            self.redSlimeImage = self.redSlimeSprites[self.currentRedSlimeSprite]
            self.currentRedSlimeTimer = py.time.get_ticks()
    
    def updateStoneIdle(self):
        if py.time.get_ticks() > self.currentStoneIdleTimer + 100:
            self.currentStoneIdleSprite += 1
            if self.currentStoneIdleSprite >= len(self.stoneIdleSprites):
                self.currentStoneIdleSprite = 0
            
            self.stoneIdleImage = self.stoneIdleSprites[self.currentStoneIdleSprite]
            self.currentStoneIdleTimer = py.time.get_ticks()
    
    def updateStoneGlow(self):
        if py.time.get_ticks() > self.currentStoneGlowTimer + 100:
            self.currentStoneGlowSprite += 1
            if self.currentStoneGlowSprite >= len(self.stoneGlowSprites):
                self.currentStoneGlowSprite = 0
            
            self.stoneGlowImage = self.stoneGlowSprites[self.currentStoneGlowSprite]
            self.currentStoneGlowTimer = py.time.get_ticks()
    
    def updateStoneRange(self):
        if py.time.get_ticks() > self.currentStoneRangeTimer + 100:
            self.currentStoneRangeSprite += 1
            if self.currentStoneRangeSprite >= len(self.stoneRangeSprites):
                self.currentStoneRangeSprite = 0
            
            self.stoneRangeImage = self.stoneRangeSprites[self.currentStoneRangeSprite]
            self.currentStoneRangeTimer = py.time.get_ticks()
    
    def updateStoneImmune(self):
        if py.time.get_ticks() > self.currentStoneImmuneTimer + 100:
            self.currentStoneImmuneSprite += 1
            if self.currentStoneImmuneSprite >= len(self.stoneImmuneSprites):
                self.currentStoneImmuneSprite = 0
            
            self.stoneImmuneImage = self.stoneImmuneSprites[self.currentStoneImmuneSprite]
            self.currentStoneImmuneTimer = py.time.get_ticks()
    
    def updateStoneMelee(self):
        if py.time.get_ticks() > self.currentStoneMeleeTimer + 100:
            self.currentStoneMeleeSprite += 1
            if self.currentStoneMeleeSprite >= len(self.stoneMeleeSprites):
                self.currentStoneMeleeSprite = 0
            
            self.stoneMeleeImage = self.stoneMeleeSprites[self.currentStoneMeleeSprite]
            self.currentStoneMeleeTimer = py.time.get_ticks()
    
    def updateStoneLaser(self):
        stoneLaserDelay = 120
        if py.time.get_ticks() > self.currentStoneLaserTimer + stoneLaserDelay:
            self.currentStoneLaserSprite += 1
            if self.currentStoneLaserSprite >= len(self.stoneLaserSprites):
                self.currentStoneLaserSprite = 0
            
            self.stoneLaserImage = self.stoneLaserSprites[self.currentStoneLaserSprite]
            self.currentStoneLaserTimer = py.time.get_ticks()
    
    def updateStoneArmour(self):
        if py.time.get_ticks() > self.currentStoneArmourTimer + 100:
            self.currentStoneArmourSprite += 1
            if self.currentStoneArmourSprite >= len(self.stoneArmourSprites):
                self.currentStoneArmourSprite = 0
            
            self.stoneArmourImage = self.stoneArmourSprites[self.currentStoneArmourSprite]
            self.currentStoneArmourTimer = py.time.get_ticks()
    
    def updateStoneAppear(self):
        appearDelay = 150
        if py.time.get_ticks() > self.currentStoneAppearTimer + appearDelay:
            self.currentStoneAppearSprite += 1
            if self.currentStoneAppearSprite >= len(self.stoneAppearSprites):
                self.currentStoneAppearSprite = 0
            
            self.stoneAppearImage = self.stoneAppearSprites[self.currentStoneAppearSprite]
            self.currentStoneAppearTimer = py.time.get_ticks()

