import pygame as py
from pygame.locals import *

class trap():
    def __init__(self,grid,trapType):
        self.grid = grid
        self.type = trapType
        self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,16,16)
        self.activationRect0 = py.Rect((self.grid[0] - 1)*16,(self.grid[1])*16,48,496)
        self.activationRect1 = py.Rect((self.grid[0] - 1)*16,(self.grid[1])*16,48,64)
        self.activationRect2 = py.Rect((self.grid[0] - 1)*16,(self.grid[1])*16,48,32)
        self.deactivationRect2 = py.Rect((self.grid[0])*16,(self.grid[1]+3)*16,16,16)
        self.firing = False
        self.fireRect = py.Rect(self.grid[0]*16,(self.grid[1]+1)*16,16,16)
        self.arrow_list = []
        self.arrowFire = False
        self.arrowFireCooldown = 0
        self.fire_list = []
        self.fireFire = False
        self.fireFireCooldown = 0
        self.poisonFire = False
        self.poisonFireCooldown = 0
    
    def checkFire(self,player):
        if self.type == 0:
            if player.colliderect(self.activationRect0):
                self.arrowFire = True
            else:
                self.arrowFire = False
            

        elif self.type == 1:
            if player.colliderect(self.activationRect1):
                self.fireFire = True
            else:
                self.fireFire = False
        
        elif self.type == 2:
            if player.colliderect(self.activationRect2):
                self.poisonFire = True
            else:
                self.poisonFire = False

