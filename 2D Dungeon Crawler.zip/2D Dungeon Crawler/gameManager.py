import pygame as py
from pygame.locals import *

class GameManager():
    def __init__(self):
        self.menu = "main"
        self.rect = (0,0,1280,720)
        self.roomEntered = 0
        self.roomExited = 0
        self.levelRewardPoints = 0
        self.level = 1
        self.resetting = False
        self.backgroundImage = py.image.load("main_menu.png")
    
    def LoadScreen(self,screen):
        if self.menu == "main":
            screen.blit(self.backgroundImage,self.rect)
    
    def setRoomEntered(self,time):
        self.roomEntered = time
    
    def setRoomExited(self,time):
        self.roomExited = time
    
    def RewardPoints(self):
        reward = self.roomExited - self.roomEntered
        if reward < 10000:
            return 500
        elif reward < 15000:
            return 450
        elif reward < 20000:
            return 400
        elif reward < 25000:
            return 350
        elif reward < 30000:
            return 300
        else:
            return 100
