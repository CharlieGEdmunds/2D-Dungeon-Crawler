import pygame as py
from pygame.locals import *

class key():
    def __init__(self,grid):
        self.grid = grid
        self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,16,16)
        self.pickedUp = False
        self.doorUnlocked = False
    
    def pickUp(self,player):
        if player.colliderect(self.rect):
            self.pickedUp = True
            self.doorUnlocked = True
    