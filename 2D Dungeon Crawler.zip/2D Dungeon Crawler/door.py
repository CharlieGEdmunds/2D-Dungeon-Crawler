import math
import pygame as py
from pygame.locals import *

class door():
    def __init__(self,grid):
        self.grid = grid
        self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,16,16)
