import pygame as py
from pygame.locals import *

BLOCKSIZE = 16

class coin():
    def __init__(self,grid,type,value):
        self.grid = grid
        self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,16,16)
        self.type = type
        self.pickedUp = False
        self.value = value
    
    def pickUp(self,player):
        if player.colliderect(self.rect):
            self.pickedUp = True
