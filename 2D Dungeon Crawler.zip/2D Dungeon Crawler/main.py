import pygame as py
import random as r
from pygame.locals import *
from block import *
from levels import *
from player import *
from enemy import *
from key import *
from coin import *
from trap import *
from arrow import *
from weapon import *
from button import *
from chest import *
from chestKey import *
from gameManager import *
from portal import *
from NPC import *

#creates important constants such as the dimensions of the screen and the FPS
display_width = 1280
display_height = 720
FPS = 60
BLOCKSIZE = 32

# Variables to keep track of timers for animating things like door and keys
doorWait = 0
currentDoorSprite = 0
currentDoor2Sprite = 0
coinWait = 0
currentCoinSprite = 0
chestWait = 0
currentChestSprite = 0
bigChestWait = 0
currentBigChestSprite = 0
doorOpenTimer = 0
saveChests = False

# Initialises parts of the pygame library so they work while running such as fonts
py.font.init()
py.init()
py.mixer.init()
keys = py.key.get_pressed()
clock = py.time.Clock()
myFont = py.font.SysFont("Arial",32)
player1Money = myFont.render("£ 0",True,(255,255,255))
player1Score = myFont.render("£ 0",True,(255,255,255))
levelRewardPoints = 0

leaderboard1 = myFont.render("",True,(255,255,255))
leaderboard2 = myFont.render("",True,(255,255,255))
leaderboard3 = myFont.render("",True,(255,255,255))
leaderboard4 = myFont.render("",True,(255,255,255))
leaderboard5 = myFont.render("",True,(255,255,255))
leaderboard6 = myFont.render("",True,(255,255,255))
leaderboard7 = myFont.render("",True,(255,255,255))
leaderboard8 = myFont.render("",True,(255,255,255))
leaderboard9 = myFont.render("",True,(255,255,255))
leaderboard10 = myFont.render("",True,(255,255,255))

leaderboardList = [leaderboard1,leaderboard2,leaderboard3,leaderboard4,leaderboard5,leaderboard6,leaderboard7,leaderboard8,leaderboard9,leaderboard10]


#creates the colour palet
black = (0,0,0)
white = (255,255,255)
red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)
yellow = (255,255,0)
back = (37,19,26)

# Creates the game window and gives it a name
screen = py.display.set_mode((display_width,display_height), py.FULLSCREEN)
py.display.set_caption("Bullet Bonanza")

# Loads grouped images into list and makes single images into variables
wall_images = [
    py.image.load("1.png").convert_alpha(),
    py.image.load("1.png").convert_alpha(),
    py.image.load("2.png").convert_alpha(),
    py.image.load("3.png").convert_alpha(),
    py.image.load("4.png").convert_alpha(),
    py.image.load("5.png").convert_alpha(),
    py.image.load("6.png").convert_alpha(),
    py.image.load("7.png").convert_alpha(),
    py.image.load("8.png").convert_alpha(),
    py.image.load("9.png").convert_alpha(),
    py.image.load("10.png").convert_alpha(),
    py.image.load("11.png").convert_alpha(),
    py.image.load("12.png").convert_alpha(),
    py.image.load("13.png").convert_alpha(),
    py.image.load("14.png").convert_alpha(),
    py.image.load("15.png").convert_alpha(),
    py.image.load("16.png").convert_alpha(),
    py.image.load("17.png").convert_alpha(),
    py.image.load("18.png").convert_alpha(),
    py.image.load("19.png").convert_alpha(),
    py.image.load("20.png").convert_alpha(),
    py.image.load("21.png").convert_alpha(),
    py.image.load("22.png").convert_alpha(),
    py.image.load("23.png").convert_alpha(),
    py.image.load("24.png").convert_alpha(),
    py.image.load("25.png").convert_alpha(),
    py.image.load("26.png").convert_alpha(),
    py.image.load("27.png").convert_alpha(),
    py.image.load("28.png").convert_alpha(),
    py.image.load("29.png").convert_alpha(),
    py.image.load("30.png").convert_alpha(),
    py.image.load("31.png").convert_alpha(),
    py.image.load("32.png").convert_alpha(),
    py.image.load("33.png").convert_alpha(),
    py.image.load("34.png").convert_alpha(),
    py.image.load("35.png").convert_alpha()
]

door_images = [
    py.image.load("door1.png").convert_alpha(),
    py.image.load("door2.png").convert_alpha(),
    py.image.load("door3.png").convert_alpha(),
    py.image.load("door4.png").convert_alpha(),
]

chest_images = [
    py.image.load("chest1.png").convert_alpha(),
    py.image.load("chest2.png").convert_alpha(),
    py.image.load("chest3.png").convert_alpha(),
    py.image.load("chest4.png").convert_alpha(),
]

big_chest_images = [
    py.image.load("bigChest1.png").convert_alpha(),
    py.image.load("bigChest2.png").convert_alpha(),
    py.image.load("bigChest3.png").convert_alpha(),
    py.image.load("bigChest4.png").convert_alpha(),
]

coin_images = [
    py.image.load("gold_coin.png").convert_alpha()
]

bronze_coin_images = [
    py.image.load("BronzeCoin1.png").convert_alpha(),
    py.image.load("BronzeCoin2.png").convert_alpha(),
    py.image.load("BronzeCoin3.png").convert_alpha(),
    py.image.load("BronzeCoin4.png").convert_alpha(),
]

silver_coin_images = [
    py.image.load("SilverCoin1.png").convert_alpha(),
    py.image.load("SilverCoin2.png").convert_alpha(),
    py.image.load("SilverCoin3.png").convert_alpha(),
    py.image.load("SilverCoin4.png").convert_alpha(),
]

gold_coin_images = [
    py.image.load("gold_coin_1.png").convert_alpha(),
    py.image.load("gold_coin_2.png").convert_alpha(),
    py.image.load("gold_coin_3.png").convert_alpha(),
    py.image.load("gold_coin_4.png").convert_alpha(),
]

trap_images = [
    py.image.load("arrow_trap.png").convert_alpha(),
    py.image.load("fire_trap.png").convert_alpha(),
    py.image.load("poison_trap.png").convert_alpha(),
]

smallTentacle = py.image.load("smallTentacle1.png")
arrowImage = py.image.load("arrow.png").convert_alpha()
arrowHit = py.image.load("arrowHit.png").convert_alpha()
fireImage = py.image.load("fire.png").convert_alpha()
poisonImage = py.image.load("poison.png").convert_alpha()
healthBarImage = py.image.load("healthBar.png").convert_alpha()
healthBarDecoration = py.image.load("healthBarDecoration.png").convert_alpha()
bossHealthBarImage = py.image.load("healthBar.png").convert_alpha()
bossHealthBarDecoration = py.image.load("healthBarDecoration.png").convert_alpha()
gold_key = py.image.load("gold_key.png").convert_alpha()

# Creates the lists the projectiles are added to when fired
arrow_list = []
fire_list = []
poison_list = []

NPCList = []

# Variable for where the player is in terms of which room they are in and their current place in the menu
p1Level = 0
currentMenu = "main"
rewardBool = False
boss4Angle = 0

def createWalls(level,xpar):
    walls = []
    x = xpar
    y = 3
    ypar = 3
    for row in level:
        for column in row:
            if column == "#":
                #Edge cases
                if x == xpar:
                    if y == ypar:
                        new_wall = block((x,y), 10)
                    elif y == ypar + 39:
                        new_wall = block((x,y), 12)
                    else:
                        new_wall = block((x,y), 15)
                elif x == xpar + 63:
                    if y == ypar:
                        new_wall = block((x,y), 11)
                    elif y == ypar + 39:
                        new_wall = block((x,y), 13)
                    else:
                        new_wall = block((x,y), 16)
                elif y == ypar:
                    new_wall = block((x,y), 3)
                elif y == ypar + 39:
                    new_wall = block((x,y), 5)

                elif (level[y-ypar-1][x-xpar] == "#") and (level[y+1-ypar][x-xpar] == "#") and (level[y-ypar][x-1-xpar] != "#") and (level[y-ypar][x+1-xpar] == "#") and (level[y-ypar+1][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar+1] != "#"):
                    new_wall = block((x,y),30)

                elif (level[y-ypar-1][x-xpar] == "#") and (level[y+1-ypar][x-xpar] == "#") and (level[y-ypar][x-1-xpar] == "#") and (level[y-ypar][x+1-xpar] != "#") and (level[y-ypar+1][x-xpar-1] == "#") and (level[y-ypar-1][x-xpar-1] != "#"):
                    new_wall = block((x,y),31)

                elif (level[y-ypar-1][x-xpar] == "#") and (level[y+1-ypar][x-xpar] == "#") and (level[y-ypar][x-1-xpar] != "#") and (level[y-ypar][x+1-xpar] == "#") and (level[y-ypar-1][x-xpar+1] == "#") and (level[y-ypar+1][x-xpar+1] != "#"):
                    new_wall = block((x,y),33)

                elif (level[y-ypar-1][x-xpar] == "#") and (level[y+1-ypar][x-xpar] == "#") and (level[y-ypar][x-1-xpar] == "#") and (level[y-ypar][x+1-xpar] != "#") and (level[y-ypar+1][x-xpar-1] != "#") and (level[y-ypar-1][x-xpar-1] == "#"):
                    new_wall = block((x,y),32)                

                # central
                elif (level[y-ypar-1][x-xpar] == "#") and (level[y+1-ypar][x-xpar] == "#") and (level[y-ypar][x-1-xpar] == "#") and (level[y-ypar][x+1-xpar] == "#"):
                    new_wall = block((x,y),17)
                

                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] == "#") and (level[y-ypar+1][x-xpar-1] != "#"):
                    new_wall = block((x,y),28)

                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] != "#") and (level[y-ypar+1][x-xpar+1] != "#"):
                    new_wall = block((x,y),27)

                # corners
                # top left
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),10)
                # top right
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),11)
                # bottom left
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),12)
                # bottom right
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),13)
                
                # treasure room
                # top side wall
                elif (level[y-ypar+1][x-xpar] == "@") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),3)
                #left side wall
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] == "@") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),15)
                # right side wall
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] == "@"):
                    new_wall = block((x,y),16)
                # doors
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] == "@") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),23)


                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] == "#") and (level[y-ypar+1][x-xpar-1] == "#"):
                    new_wall = block((x,y),25)

                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] != "#") and (level[y-ypar+1][x-xpar+1] == "#"):
                    new_wall = block((x,y),26)
                

                #sides
                # vertical sides
                # left
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),15)
                # right
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),16)

                # horizontal sides
                # up
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),3)
                # down
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),5)

                # central pieces
                # horizontal
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),5)
                # vertical
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),20)

                # edge pieces
                # left
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),12)
                # right
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),13)
                # up
                elif (level[y-ypar+1][x-xpar] == "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] != "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),21)
                # down
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] != "#") and (level[y-ypar-1][x-xpar] == "#") and (level[y-ypar][x-xpar-1] != "#"):
                    new_wall = block((x,y),22)
                


                # everything else    
                else:
                    new_wall = block((x,y), 1)
            elif column == "&":
                # left door
                if (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "&") and (level[y-ypar-1][x-xpar] == "@") and (level[y-ypar][x-xpar-1] == "#"):
                    new_wall = block((x,y),23)
                # right door
                elif (level[y-ypar+1][x-xpar] != "#") and (level[y-ypar][x-xpar+1] == "#") and (level[y-ypar-1][x-xpar] == "@") and (level[y-ypar][x-xpar-1] == "&"):
                    new_wall = block((x,y),23)
                else:
                    new_wall = block((x,y), 1)  
            elif (column != "#" or " ") and x == xpar and y == 3:
                new_wall = block((x,y), 10)

            elif column == "?":
                if x == xpar:
                    if currentRoom != 0:
                        if map[currentFloor][currentRoom-1] != '':
                            new_wall = block((x,y),34)
                        else:
                            new_wall = block((x,y),35)
                    else:
                        new_wall = block((x,y),35)
                
                elif x == xpar + 63:
                    if currentRoom != 2:
                        if map[currentFloor][currentRoom+1] != '':
                            new_wall = block((x,y),34)
                        else:
                            new_wall = block((x,y),35)
                    else:
                        new_wall = block((x,y),35)
                
                elif y == ypar:
                    if currentFloor != 0:
                        if map[currentFloor-1][currentRoom] != '':
                            new_wall = block((x,y),34)
                        else:
                            new_wall = block((x,y),35)
                    else:
                        new_wall = block((x,y),35)
                
                elif y == ypar + 39:
                    if currentFloor != 2:
                        if map[currentFloor+1][currentRoom] != '':
                            new_wall = block((x,y),34)
                        else:
                            new_wall = block((x,y),35)
                    else:
                        new_wall = block((x,y),35)

            elif column == ">":
                NPCList.append(NPCs(py.Rect(x * 16,y * 16,32,32),"Vendor"))
                new_wall = block((x,y), 1)  
            
            elif column == ">":
                NPCList.append(NPCs(py.Rect(x * 16,y * 16,32,32),"Brewer"))
                new_wall = block((x,y), 1)  

            else:
                new_wall = block((x,y), 1)  

            walls.append(new_wall)
            x += 1       
        x = xpar
        y += 1
    return walls

# Creates all walls, enemies, traps, players etc using functions in the level script
for i in range(3):
    CreateLevel(i)
gameManager = GameManager()
player1 = createPlayer()
enemy1 = createEnemies(map[currentFloor][currentRoom],9)
key1 = createKey(map[currentFloor][currentRoom],9)
coins1 = createCoins(map[currentFloor][currentRoom],9)
traps1 = createTraps(map[currentFloor][currentRoom],9)
weapons1 = createWeapons(map[currentFloor][currentRoom],9)
walls = createWalls(preGame,9)
chests = createChests(map[currentFloor][currentRoom])
chestKeys = []

# Variables for testing if the player has changed room
p1RoomUpdate = False
p1RoomUpdateTimer = 0
p1ShopUpdate = False
p1ShopUpdateTimer = 0
p1ShopUpdateBool = True

# THIS CAUSES AN ERROR SOMEWHERE
player1.weapon.pickupRect = py.Rect(player1.rect.x, player1.rect.y,16,16)
# THIS CAUSES AN ERROR SOMEWHERE

# Initialises the animation frames for the player and enemies
player1.images()
for e in enemy1:
    e.images()

def move():
    p1Ymove = 0
    p1Xmove = 0
    if keys[py.K_w]:
        p1Ymove = -player1.speed
    elif keys[py.K_s]:
        p1Ymove = player1.speed
    if keys[py.K_a]:
        p1Xmove = -player1.speed
        player1.facing = "left"
    elif keys[py.K_d]:
        p1Xmove = player1.speed
        player1.facing = "right"
    
    if keys[py.K_w] and keys[py.K_d]:
        p1Xmove = math.sqrt(player1.speed * 2)
        p1Ymove = -p1Xmove
    if keys[py.K_w] and keys[py.K_a]:
        p1Xmove = -math.sqrt(player1.speed * 2)
        p1Ymove = p1Xmove
    if keys[py.K_s] and keys[py.K_d]:
        p1Xmove = math.sqrt(player1.speed * 2)
        p1Ymove = p1Xmove
    if keys[py.K_s] and keys[py.K_a]:
        p1Xmove = -math.sqrt(player1.speed * 2)
        p1Ymove = -p1Xmove
    
    player1.move(p1Xmove,p1Ymove,walls)
    
    if keys[K_w] or keys[K_a] or keys[K_s] or keys[K_d]:
        player1.isMoving = True
    else:
        player1.isMoving = False

def PlayerMove():
    if not player1.isAttacking and not player1.isDamaged and not player1.isParrying:
            move()

def playerAnimate():
    if player1.character == "ninja":
        if player1.isDamaged:
            player1.updateDamaged()
            screen.blit(player1.damagedImage,player1.rect)
        elif player1.isParrying:
            player1.updateParry()
            screen.blit(player1.parryImage,player1.rect)
        elif player1.isAttacking:
            player1.updateAttack()
            screen.blit(player1.attackImage,player1.rect)
        elif player1.isMoving:
            player1.updateMove()
            screen.blit(player1.moveImage,player1.rect)
        elif not player1.isMoving:
            player1.updateIdle()
            screen.blit(player1.idleImage,player1.rect)
    player1.initialise()

    if player1.character == "menu":
        py.draw.rect(screen,red,player1.rect)
    elif player1.character == "knight":
        py.draw.rect(screen,red,player1.rect)
    elif player1.character == "archer":
        if player1.isDamaged:
            player1.updateDamaged()
            screen.blit(player1.damagedImage,player1.rect)
        elif player1.isParrying:
            player1.updateParry()
            screen.blit(player1.parryImage,player1.rect)
        elif player1.isAttacking:
            player1.updateAttack()
            screen.blit(player1.attackImage,player1.rect)
        elif player1.isMoving:
            player1.updateMove()
            screen.blit(player1.moveImage,player1.rect)
        elif not player1.isMoving:
            player1.updateIdle()
            screen.blit(player1.idleImage,player1.rect)
    elif player1.character == "mage":
        py.draw.rect(screen,(255,0,255),player1.rect)

def PlayerAttack():
    global enemy1, randomCrit, player1
    # Allows the player to attack if it isnt damaged
    if not player1.isDamaged:
        if py.mouse.get_pressed() == (1,0,0):
            player1.isAttacking = True
            if player1.character == "ninja":
                for e in enemy1:
                    if player1.weapon.hitbox.colliderect(e.rect) and py.time.get_ticks() > e.hitstun + player1.weapon.attackSpeed * 5:
                        if player1.weapon.infExplosion and py.time.get_ticks() > player1.explosionCooldown + 10000:
                            player1.creExplosion = True
                            player1.explosionTimer = py.time.get_ticks()
                            player1.explosionCooldown = py.time.get_ticks()
                        if player1.weapon.infKnockback:
                            player1.creKnockback = True
                        if player1.weapon.infHeal:
                            player1.creHeal = True
                        if player1.weapon.infCrit:
                            randomCrit = r.randint(1,1/player1.weapon.critChance)
                            if randomCrit == 1:
                                player1.crit = True
                        if not player1.crit:
                            playerPos = py.math.Vector2(player1.rect.x, player1.rect.y)
                            mousePos = py.math.Vector2(py.mouse.get_pos()[0],py.mouse.get_pos()[1])
                            lookDirection = py.math.Vector2(mousePos - playerPos)
                            angle = math.atan2(lookDirection[1],lookDirection[0])
                            x = math.cos(angle) * player1.weapon.knockback
                            y = math.sin(angle) * player1.weapon.knockback
                            e.rect.x += x
                            e.rect.y += y
                            e.newPosition[0] += x
                            e.newPosition[1] += y
                            e.damaged(player1.weapon.damage,player1.weapon.armourPen)
                            if e.enemyType != 100 and e.enemyGroup == "bat" and e.enemyGroup == "bat":
                                e.fireTimer = py.time.get_ticks() - e.shotDelay / 2
                        elif player1.crit:
                            e.damaged(player1.weapon.damage * 2,1)
                            if e.enemyType != 100 and e.enemyGroup == "bat":
                                e.fireTimer = py.time.get_ticks() - e.shotDelay / 2
                            player1.crit = False
                    if player1.explosionRect.colliderect(e.rect) and py.time.get_ticks() > e.hitstun + 1000:
                        e.damaged(player1.weapon.explosionDamage,player1.weapon.armourPen)
                        if e.enemyType != 100 and e.enemyGroup == "bat":
                            e.fireTimer = py.time.get_ticks() - e.shotDelay / 2
                    if e.health <= 0:
                        enemy1.remove(e)
                        player1.score += (e.enemyType * 10)

            elif player1.character == "archer":
                if py.time.get_ticks() > player1.lastFired + player1.attackSpeed * 5:
                    if not player1.multiShot:
                        player1.bulletList.append(bullet(player1.rect.x,player1.rect.y,py.mouse.get_pos()[0],py.mouse.get_pos()[1],3,10,player1.rect,0,0))
                        player1.lastFired = py.time.get_ticks()
                    else:
                        for i in range(3):
                            player1.bulletList.append(bullet(player1.rect.x,player1.rect.y,py.mouse.get_pos()[0],py.mouse.get_pos()[1],3,10,player1.rect,i,720))
                        player1.lastFired = py.time.get_ticks()
                        player1.multiShot = False

    for b in player1.bulletList:
        b.archerFire()
        py.draw.rect(screen,red,b.newRect)
        for e in enemy1:
            if b.newRect.colliderect(e.rect) and py.time.get_ticks() > e.hitstun + player1.weapon.attackSpeed * 8:
                e.damaged(5,10)
                if e.enemyType != 100 and e.enemyGroup == "bat":
                    e.fireTimer = py.time.get_ticks() - e.shotDelay / 2
            if e.health <= 0:
                player1.score += (e.enemyType * 10)
                enemy1.remove(e)
    
    player1.attack()

    if player1.changeWeapon:
        player1.change_weapon()

def PlayerAttackEffects():
    if player1.doubleDamage:
        player1.weapon.damage /= 2
        player1.doubleDamage = False

    if player1.creExplosion:
        player1.explosionRect = py.Rect(player1.weapon.hitbox.x - 16, player1.weapon.hitbox.y - 16, 48,48)
        py.draw.rect(screen,red,player1.explosionRect)
        if py.time.get_ticks() > player1.explosionTimer + 1000:
            player1.weapon.infExplosion = False
            player1.creExplosion = False
            
    if player1.creHeal:
        player1.healthAmount += player1.weapon.damage*player1.weapon.healAmount
        player1.creHeal = False
        player1.weapon.infHeal = False
        player1.healthLost = (100 - player1.healthAmount) * 0.49
        player1.healthLostRect.x = 96 - player1.healthLost
            
    if player1.healthAmount > 100:
        player1.healthAmount = 100

def playerLook(playerPos, mousePos):
    lookDirection = py.math.Vector2(mousePos - playerPos)
    angle = math.atan2(lookDirection[1],lookDirection[0])
    x = math.cos(angle) * 22
    y = math.sin(angle) * 22
    tempRect = py.Rect(player1.rect.x,player1.rect.y,22,22)
    tempRect.centerx += x
    tempRect.centery += y
    player1.weapon.hitbox = tempRect

def WeaponDraw():
    screen.blit((player1.weapon.image),(player1.weapon.hitbox))

def EnemyDraw():
    for e in enemy1:
        if e.enemyGroup == "bat":
            e.batAI(player1.rect,walls)
        elif e.enemyGroup == "slime":
            e.slimeAI(player1.rect,walls)
        elif e.enemyGroup == "akaname":
            e.akanameAI(player1.rect,walls)
        elif e.enemyGroup == "fishfolk":
            e.fishfolkAI(player1.rect,walls)
        elif e.enemyGroup == "boss":
            e.bossAI(player1)

def EnemyFire():
    # Allows enemies to fire at the players
    for e in enemy1:
        if e.enemyGroup == "bat":
            if py.time.get_ticks() > e.fireTimer + e.shotDelay:
                e.fire(player1)
                e.fireTimer = py.time.get_ticks()
        if e.enemyGroup == "slime":
            e.hit(player1)

def BulletMove():
    for e in enemy1:
        for b in e.bulletList1:
            b.fire()
            screen.blit(e.shotImage,b.newRect)
        
        for b in e.bossBulletList:
            if e.randomAttack == 1:
                b.bossFire1()
            elif e.randomAttack == 2 and not py.time.get_ticks() > b.creationTime + 3500:
                b.bossFire2()
                if py.time.get_ticks() > b.creationTime + 2500 and not e.splitBool:
                    e.split(player1,b.newRect)
                    e.splitCount += 1
            elif e.randomAttack == 2 and py.time.get_ticks() > b.creationTime + 4000:
                if not e.homingBool:
                    newB = bullet(b.newRect.x,b.newRect.y,player1.rect.x,player1.rect.y,8,16,b.newRect,0,0)
                    e.bossBulletList2.append(newB)
                    e.homingCount += 1
                    e.bossBulletList.remove(b)
            elif e.randomAttack == 3:
                b.bossFire3()
            elif e.randomAttack == 4:
                b.bossFire4()
            screen.blit(e.shotImage,b.newRect)
    
        if e.splitCount >= 4:
            e.splitBool = True

        if e.homingCount >= 4:
            e.homingBool = True
        
        for e in enemy1:
            for b in e.bossBulletList2:
                b.bossFire1()
                screen.blit(e.shotImage,b.newRect)
        
        if e.enemyGroup == "boss":
            if e.bossFire3Start:
                for b in e.bossBulletList:
                    if py.time.get_ticks() > b.creationTime + 3600:
                        b.boss3InnerCircleDist -= 1
                    elif py.time.get_ticks() > b.creationTime + 2400:
                        b.boss3InnerCircleDist += 1
                    elif py.time.get_ticks() > b.creationTime + 1200:
                        b.boss3InnerCircleDist -= 1
                    else:
                        b.boss3InnerCircleDist += 1

                    if py.time.get_ticks() > b.creationTime + 3600:
                        b.boss3OuterCircleDist -= 2
                    elif py.time.get_ticks() > b.creationTime + 2400:
                        b.boss3OuterCircleDist += 2
                    elif py.time.get_ticks() > b.creationTime + 1200:
                        b.boss3OuterCircleDist -= 2
                    else:
                        b.boss3OuterCircleDist += 2

def BulletCollide():
    # Checks if the bullets collide with the player or the walls and if so removes them and damages player
    for e in enemy1:
        for w in walls:
            for b in e.bulletList1:
                if b.newRect.colliderect(player1.rect) and not player1.invisible:
                    player1.hit(e.shotDamage)
                    e.bulletList1.remove(b)
                if b.newRect.colliderect(w.rect) and w.index != 1:
                    e.bulletList1.remove(b)
    
    for e in enemy1:
        for w in walls:
            for b in e.bossBulletList:
                if b.newRect.colliderect(player1.rect) and not player1.invisible:
                    player1.hit(e.shotDamage)
                    b.bulletCollided = True
                if b.newRect.colliderect(w.rect) and w.index != 1:
                    b.bulletCollided = True
                if b.bulletCollided:
                    e.bossBulletList.remove(b)
            for b in e.bossBulletList2:
                if b.newRect.colliderect(player1.rect) and not player1.invisible:
                    player1.hit(e.shotDamage)
                    b.bulletCollided = True
                if b.newRect.colliderect(w.rect) and w.index != 1:
                    b.bulletCollided = True
                if b.bulletCollided:
                    e.bossBulletList2.remove(b)
    
def EnemyAnimate():
    if len(enemy1) != 0:
        for e in enemy1:
            if e.enemyType == 1 and e.enemyGroup == "bat":
                e.updateBat()
                if e.hitstunAnimation:
                    e.batImage.set_alpha(127)
                else:
                    e.batImage.set_alpha(256)
                screen.blit(e.batImage,e.rect)

            elif e.enemyType == 1 and e.enemyGroup == "slime":
                e.updateBlueSlime()
                if e.hitstunAnimation:
                    e.blueSlimeImage.set_alpha(127)
                else:
                    e.blueSlimeImage.set_alpha(256)
                screen.blit(e.blueSlimeImage,e.rect)

            elif e.enemyType == 2 and e.enemyGroup == "bat":
                e.updateRadioactiveBat()
                if e.hitstunAnimation:
                    e.radioactiveBatImage.set_alpha(127)
                else:
                    e.radioactiveBatImage.set_alpha(256)
                screen.blit(e.radioactiveBatImage,e.rect)

            elif e.enemyType == 2 and e.enemyGroup == "slime":
                e.updateGreenSlime()
                if e.hitstunAnimation:
                    e.greenSlimeImage.set_alpha(127)
                else:
                    e.greenSlimeImage.set_alpha(256)
                screen.blit(e.greenSlimeImage,e.rect)

            elif e.enemyType == 3 and e.enemyGroup == "bat":
                e.updateSpaceBat()
                if e.hitstunAnimation:
                    e.spaceBatImage.set_alpha(127)
                else:
                    e.spaceBatImage.set_alpha(256)
                screen.blit(e.spaceBatImage,e.rect)
            
            elif e.enemyType == 3 and e.enemyGroup == "slime":
                e.updateRedSlime()
                if e.hitstunAnimation:
                    e.redSlimeImage.set_alpha(127)
                else:
                    e.redSlimeImage.set_alpha(256)
                screen.blit(e.redSlimeImage,e.rect)
            
            elif e.enemyType == 4 and e.isMoving:
                e.updateAkanameMove()
                if e.hitstunAnimation:
                    e.akanameImage.set_alpha(127)
                else:
                    e.akanameImage.set_alpha(256)
                screen.blit(e.akanameImage,e.imageRect)
            
            elif e.enemyType == 4 and e.isAttacking:
                e.updateAkanameAttack()
                if e.hitstunAnimation:
                    e.akanameImage.set_alpha(127)
                else:
                    e.akanameImage.set_alpha(256)
                screen.blit(e.akanameImage,e.imageRect)

                if e.damageRect.colliderect(player1.rect):
                    player1.hit(e.damage)

            elif e.enemyType == 5 and e.isMoving:
                e.updateBrainMoleMove()
                if e.hitstunAnimation:
                    e.brainMoleImage.set_alpha(127)
                else:
                    e.brainMoleImage.set_alpha(256)
                screen.blit(e.brainMoleImage,e.imageRect)
            
            elif e.enemyType == 5 and e.isAttacking:
                e.updateBrainMoleAttack()
                if e.hitstunAnimation:
                    e.brainMoleImage.set_alpha(127)
                else:
                    e.brainMoleImage.set_alpha(256)
                screen.blit(e.brainMoleImage,e.imageRect)

                if e.damageRect.colliderect(player1.rect):
                    player1.hit(e.damage)

            elif e.enemyType == 6 and e.isMoving:
                e.updateFishfolkMove()
                if e.hitstunAnimation:
                    e.fishfolkImage.set_alpha(127)
                else:
                    e.fishfolkImage.set_alpha(256)
                screen.blit(e.fishfolkImage,e.imageRect)

            elif e.enemyType == 6 and e.isAttacking:
                e.updateFishfolkAttack()
                if e.hitstunAnimation:
                    e.fishfolkImage.set_alpha(127)
                else:
                    e.fishfolkImage.set_alpha(256)
                screen.blit(e.fishfolkImage,e.imageRect)

                if e.damageRect.colliderect(player1.rect):
                    player1.hit(e.damage)
            
            elif e.enemyType == 6 and e.isHooking:
                e.updateFishfolkHook()
                if e.hitstunAnimation:
                    e.fishfolkImage.set_alpha(127)
                else:
                    e.fishfolkImage.set_alpha(256)
                screen.blit(e.fishfolkImage,e.imageRect)

                if e.damageRect.colliderect(player1.rect):
                    player1.hit(e.damage)
                    if py.time.get_ticks() > player1.hookedCooldown + 2500:
                        player1.stunned(1000)
                        player1.hookedCooldown = py.time.get_ticks()
                        if e.facing == "left":
                            player1.hooked("left")
                        else:
                            player1.hooked("right")

    if len(enemy1) != 0:
        # bosses
        for e in enemy1:
            if e.enemyType == 100:
                if e.bossIsIdle:
                    e.updateStoneIdle()
                    screen.blit(e.stoneIdleImage,e.rect)
                elif e.bossIsGlowing:
                    e.updateStoneGlow()
                    screen.blit(e.stoneGlowImage,e.rect)
                elif e.bossIsRange:
                    e.updateStoneRange()
                    screen.blit(e.stoneRangeImage,e.rect)
                elif e.bossIsImmune:
                    e.updateStoneImmune()
                    screen.blit(e.stoneImmuneImage,e.rect)
                elif e.bossIsMelee:
                    e.updateStoneMelee()
                    screen.blit(e.stoneMeleeImage,e.rect)
                elif e.bossIsLaser:
                    e.updateStoneLaser()
                    screen.blit(e.stoneLaserImage,e.rect)
                elif e.bossIsArmour:
                    e.updateStoneArmour()
                    screen.blit(e.stoneArmourImage,e.rect)
                elif e.bossIsAppear:
                    e.updateStoneAppear()
                    screen.blit(e.stoneAppearImage,e.rect)

def PlayerHealth():
    #creates the players health bar
    player1.health(screen,healthBarImage,healthBarDecoration)

    #Fills the screen red if the player dies
    if player1.dead:
        gameManager.menu = "lose"

def ChangeRoom():
    global p1RoomUpdate,p1RoomUpdateTimer,doorOpenTimer,currentFloor,currentRoom,saveChests,walls,chests,enemy1
    for w in walls:
        if w.index == 34:
            if player1.rect.colliderect(w) and len(enemy1) == 0:
                if len(chests) != 0:
                    saveChests = True

                if w.rect.x > 800:
                    if not saveChests:
                        map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"0")
                    else:
                        for chest in chests:
                            if chest.type == "small":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"1")
                            elif chest.type == "large":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"2")
                        saveChests = False
                    currentRoom += 1
                    p1RoomUpdate = True
                    p1RoomUpdateTimer = py.time.get_ticks()
                    player1.rect.x = 165

                elif w.rect.x < 400:
                    if not saveChests:
                        map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"0")
                    else:
                        for chest in chests:
                            if chest.type == "small":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"1")
                            elif chest.type == "large":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"2")
                        saveChests = False
                    currentRoom -= 1
                    p1RoomUpdate = True
                    p1RoomUpdateTimer = py.time.get_ticks()
                    player1.rect.x = 1130

                elif w.rect.y > 400:
                    if not saveChests:
                        map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"0")
                    else:
                        for chest in chests:
                            if chest.type == "small":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"1")
                            elif chest.type == "large":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"2")
                        saveChests = False
                    currentFloor += 1
                    p1RoomUpdate = True
                    p1RoomUpdateTimer = py.time.get_ticks()
                    player1.rect.y = 80

                elif w.rect.y < 300:
                    if not saveChests:
                        map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"0")
                    else:
                        for chest in chests:
                            if chest.type == "small":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"1")
                            elif chest.type == "large":
                                map[currentFloor][currentRoom] = resetLevel(map[currentFloor][currentRoom],"2")
                        saveChests = False
                    currentFloor -= 1
                    p1RoomUpdate = True
                    p1RoomUpdateTimer = py.time.get_ticks()
                    player1.rect.y = 650
                    
        if w.doorOpening:
            if py.time.get_ticks() > doorOpenTimer + 100:
                w.currentDoorSprite += 1
                if w.currentDoorSprite >= len(door_images):
                    w.currentDoorSprite = 0
                    w.doorOpening = False
                    w.doorOpened = True
                
                w.doorImage = door_images[w.currentDoorSprite]
                doorOpenTimer = py.time.get_ticks()

def UpdateRoom():
    global enemy1List, enemy1, key1, coins1, traps1, weapons1, chestKeys, NPCList, map, currentFloor, currentRoom, chests, rewardBool, p1RoomUpdate, p1RoomUpdateTimer, p1ShopUpdate, rewardLevel, walls, doorOpenTimer, doorWait
    if p1RoomUpdate:
        enemy1List = []
        enemy1 = []
        key1 = []
        coins1 = []
        traps1 = []
        weapons1 = []
        chestKeys = []
        NPCList = []
        enemy1 = createEnemies(map[currentFloor][currentRoom],9)
        for e in enemy1:
            e.images()
        key1 = createKey(map[currentFloor][currentRoom],9)
        coins1 = createCoins(map[currentFloor][currentRoom],9)
        chests = createChests(map[currentFloor][currentRoom])
        traps1 = createTraps(map[currentFloor][currentRoom],9)
        weapons1 = createWeapons(map[currentFloor][currentRoom],9)
        walls = createWalls(map[currentFloor][currentRoom],9)
        gameManager.setRoomEntered(py.time.get_ticks())
        rewardBool = False
        p1RoomUpdate = False

    if p1ShopUpdate:
        enemy1List = []
        enemy1 = []
        key1 = []
        coins1 = []
        traps1 = []
        weapons1 = []
        chestKeys = []
        NPCList = []
        enemy1 = createEnemies(shop,9)
        for e in enemy1:
            e.images()
        key1 = createKey(shop,9)
        coins1 = createCoins(shop,9)
        chests = createChests(shop)
        traps1 = createTraps(shop,9)
        weapons1 = createWeapons(shop,9)
        walls = createWalls(shop,9)
        gameManager.setRoomEntered(py.time.get_ticks())
        rewardBool = False
        p1ShopUpdate = False

    if not rewardBool:
        if len(enemy1) == 0:
            tempMap = map[currentFloor][currentRoom]
            if tempMap[0][0] != "0" and tempMap[0][0] != "1" and tempMap[0][0] != "2" and tempMap[0][0] != "S":
                rewardLevel = RewardLevel(map[currentFloor][currentRoom])
                gameManager.setRoomExited(py.time.get_ticks())
                player1.score += gameManager.RewardPoints()
            else:
                rewardLevel = 0
            rewards(rewardLevel)
            rewardBool = True
            for wall in walls:
                if wall.index == 34:
                    wall.doorOpening = True

def showWalls():
    for wall in walls:
        if key1 != 0:
            pass
        #     if key1.doorUnlocked and wall.index == 23 and currentDoorSprite <= 2:
        #         if py.time.get_ticks() > doorWait + 100:
        #             currentDoorSprite += 1
        #             doorWait = py.time.get_ticks()
            
        #         doorUnlockImage = door_images[currentDoorSprite]
        #         screen.blit(doorUnlockImage,wall.rect)

        #     elif key1.doorUnlocked and wall.index == 23 and currentDoorSprite == 3:
        #         doorUnlockImage = door_images[currentDoorSprite]
        #         screen.blit(doorUnlockImage,wall.rect)

        #     else:
                # screen.blit(wall_images[wall.index], wall.rect)
        else:
            if not wall.doorOpening and not wall.doorOpened:
                screen.blit(wall_images[wall.index], wall.rect)
            elif wall.doorOpening and not wall.doorOpened:
                screen.blit(wall.doorImage, wall.rect)
            elif wall.doorOpened:
                screen.blit(door_images[3], wall.rect)

def mainMenu():
    global player1, p1RoomUpdate, p1RoomUpdateTimer
    player1 = createPlayer()
    p1RoomUpdate = True
    p1RoomUpdateTimer = py.time.get_ticks()

    py.mouse.set_visible(True)
    playButton = Button(py.Rect(490,230,350,100),screen)
    leaderBoardButton = Button(py.Rect(490,518,350,100),screen)
    if py.mouse.get_pressed() == (1,0,0):
        mouseRect = py.Rect(py.mouse.get_pos()[0],py.mouse.get_pos()[1],1,1)
        if mouseRect.colliderect(playButton.rect):
            gameManager.menu = "preGame"
        if mouseRect.colliderect(leaderBoardButton.rect):
            gameManager.menu = "leaderboard"

def characterSelect():
    buttonList = []
    ninjaButtonImage = py.image.load("ninjaIdle1.png")
    archerButtonImage = py.image.load("archerIdle1.png")

    ninjaButton = Button(py.Rect(display_width / 7 * 3 - 48,150,96,96),screen)
    ninjaButton.loadButton(ninjaButtonImage)

    archerButton = Button(py.Rect(display_width / 7 * 4 - 48,150,96,96),screen)
    archerButton.loadButton(archerButtonImage)

    buttonList.extend([ninjaButton, archerButton])

    return buttonList

def preGameLobby():
    global walls
    showWalls()
    characterButtons = characterSelect()

    if py.mouse.get_pressed() == (1,0,0):
        mouseRect = py.Rect(py.mouse.get_pos()[0],py.mouse.get_pos()[1],1,1)
        if mouseRect.colliderect(characterButtons[0].rect):
            gameManager.menu = "game"
            walls = createWalls(map[currentFloor][currentRoom],9)
            player1.rect.x = display_width / 2
            player1.rect.y = 650
            player1.character = "ninja"
            gameManager.setRoomEntered(py.time.get_ticks())
        elif mouseRect.colliderect(characterButtons[1].rect):
            gameManager.menu = "game"
            walls = createWalls(map[currentFloor][currentRoom],9)
            player1.rect.x = display_width / 2
            player1.rect.y = 650
            player1.character = "archer"

    player1.images()

def miniMap():
    global minimap, currentRoom, currentFloor
    py.draw.rect(screen,green,py.Rect(1200,12,64,64))
    if minimap[0][0] != "":
        py.draw.rect(screen,blue,py.Rect(1204,16,16,16))
    if minimap[0][1] != "":
        py.draw.rect(screen,blue,py.Rect(1224,16,16,16))
    if minimap[0][2] != "":
        py.draw.rect(screen,blue,py.Rect(1244,16,16,16))
    if minimap[1][0] != "":
        py.draw.rect(screen,blue,py.Rect(1204,36,16,16))
    if minimap[1][1] != "":
        py.draw.rect(screen,blue,py.Rect(1224,36,16,16))
    if minimap[1][2] != "":
        py.draw.rect(screen,blue,py.Rect(1244,36,16,16))
    if minimap[2][0] != "":
        py.draw.rect(screen,blue,py.Rect(1204,56,16,16))
    if minimap[2][1] != "":
        py.draw.rect(screen,blue,py.Rect(1224,56,16,16))
    if minimap[2][2] != "":
        py.draw.rect(screen,blue,py.Rect(1244,56,16,16))
    
    if currentRoom == 0 and currentFloor == 0:
        py.draw.rect(screen,yellow,py.Rect(1204,16,16,16))
    if currentRoom == 1 and currentFloor == 0:
        py.draw.rect(screen,yellow,py.Rect(1224,16,16,16))
    if currentRoom == 2 and currentFloor == 0:
        py.draw.rect(screen,yellow,py.Rect(1244,16,16,16))
    if currentRoom == 0 and currentFloor == 1:
        py.draw.rect(screen,yellow,py.Rect(1204,36,16,16))
    if currentRoom == 1 and currentFloor == 1:
        py.draw.rect(screen,yellow,py.Rect(1224,36,16,16))
    if currentRoom == 2 and currentFloor == 1:
        py.draw.rect(screen,yellow,py.Rect(1244,36,16,16))
    if currentRoom == 0 and currentFloor == 2:
        py.draw.rect(screen,yellow,py.Rect(1204,56,16,16))
    if currentRoom == 1 and currentFloor == 2:
        py.draw.rect(screen,yellow,py.Rect(1224,56,16,16))
    if currentRoom == 2 and currentFloor == 2:
        py.draw.rect(screen,yellow,py.Rect(1244,56,16,16))

def TrapsFire():
    if len(traps1) != 0:  
        for t in traps1:
            screen.blit(trap_images[t.type],t.rect)
            t.checkFire(player1.rect)
            if t.arrowFire and py.time.get_ticks() > t.arrowFireCooldown + 1000:
                arrow_list.append(arrow(t.rect.x,t.rect.y,5,py.time.get_ticks()))
                t.arrowFireCooldown = py.time.get_ticks()
                t.arrowFire = False

            if t.fireFire and py.time.get_ticks() > t.fireFireCooldown + 500:
                fire_list.append(arrow(t.rect.x,t.rect.y,3,py.time.get_ticks()))
                t.fireFireCooldown = py.time.get_ticks()
                t.fireFire = False

            if t.poisonFire and py.time.get_ticks() > t.poisonFireCooldown + 100:
                poison_list.append(arrow(t.rect.x,t.rect.y,8,py.time.get_ticks()))
                t.poisonFireCooldown = py.time.get_ticks()
                t.poisonFire = False

def MoveTrapProjectiles():
    # Moves and removes the arrows
    for a in arrow_list:
        a.rect.y += a.speed
        screen.blit(arrowImage,a.rect)
        for wall in walls:
            if a.rect.colliderect(wall.rect) and wall.index != 1 and py.time.get_ticks() > a.fired + 100:
                arrow_list.remove(a)
        if a.rect.colliderect(player1.rect):
            arrow_list.remove(a)
        if a.rect.colliderect(player1.rect) and not player1.invisible:
            player1.hit(5)

    # Moves and removes the fireballs
    for f in fire_list:
        f.rect.y += f.speed
        screen.blit(fireImage,f.rect)
        for wall in walls:
            if wall.rect.colliderect(f.rect) and wall.index != 1 and py.time.get_ticks() > f.fired + 200:
                fire_list.remove(f)
        if f.rect.colliderect(player1.rect):
            fire_list.remove(f)
        if f.rect.colliderect(player1.rect) and not player1.invisible:
            player1.hit(10)
    
    # Moves and removes the poison
    for p in poison_list:
        p.rect.y += p.speed
        screen.blit(poisonImage,p.rect)
        for t in traps1:
            if p.rect.colliderect(t.deactivationRect2):
                poison_list.remove(p)
        if p.rect.colliderect(player1.rect) and not player1.invisible:
            player1.hit(7)

def playerDash(mousePos,playerPos):
    lookDirection = py.math.Vector2(mousePos - playerPos)
    angle = math.atan2(lookDirection[1],lookDirection[0])
    x = math.cos(angle) * 75
    y = math.sin(angle) * 75
    player1.rect = py.Rect(player1.rect.x - x, player1.rect.y - y,22,22)

def classAbilities():
    if keys[py.K_e]:
        if player1.character == "knight" and py.time.get_ticks() > player1.ability1Timer + player1.ability1Cooldown:
            player1.weapon.damage *= 2
            player1.doubleDamage = True
            player1.ability1Timer = py.time.get_ticks()
        if player1.character == "ninja" and py.time.get_ticks() > player1.ability1Timer + player1.ability1Cooldown:
            playerVector = py.math.Vector2(player1.rect.x, player1.rect.y)
            mouseVector = py.math.Vector2(py.mouse.get_pos()[0],py.mouse.get_pos()[1])
            player1.ability1Timer = py.time.get_ticks()
            playerDash(playerVector,mouseVector)
        if player1.character == "archer" and py.time.get_ticks() > player1.ability1Timer + player1.ability1Cooldown:
            player1.attackSpeed /= 3
            player1.ability1Timer = py.time.get_ticks()
            player1.attackSpeedBoost = True
    
    elif keys[py.K_q]:
        if player1.character == "ninja" and py.time.get_ticks() > player1.ability2Timer + player1.ability2Cooldown:
            player1.invisible = True
            player1.ability2Timer = py.time.get_ticks()

        if player1.character == "archer" and py.time.get_ticks() > player1.ability2Timer + player1.ability2Cooldown:
            player1.multiShot = True
            player1.ability2Timer = py.time.get_ticks()
    
    if player1.character == "ninja":
        if player1.invisible:
            if py.time.get_ticks() > player1.ability2Timer + 1000:
                player1.invisible = False

    if player1.character == "archer":
        if player1.attackSpeedBoost:
            if py.time.get_ticks() > player1.ability1Timer + 1000:
                player1.attackSpeed *= 3
                player1.attackSpeedBoost = False

def resetLevel(level,setTo):
    temp = level[0]
    tempList = list(temp)
    tempList[0] = setTo
    level[0] = ''.join(tempList)
    
    return level

def rewards(rewardMinimum):
    reward = ""
    if rewardMinimum != 0:
        rewardLevel = random.randint(rewardMinimum,100)
    else:
        return ""
    if rewardLevel <= 30:
        coins1.append(coin((player1.rect.x / 16,(player1.rect.y - 48) / 16),"bronze",10))
    elif rewardLevel <= 60:
        chestKeys.append(chestKey((player1.rect.x,player1.rect.y - 48)))
    elif rewardLevel <= 80:
        chests.append(Chest((player1.rect.x,player1.rect.y),"small"))
    elif rewardLevel <= 95:
        chests.append(Chest((player1.rect.x,player1.rect.y),"large"))
    else:
        weapons1.append(weapons((player1.rect.x,player1.rect.y - 48,20,20),RandomWeapon(1,46),(player1.rect.x / 16,(player1.rect.y - 48) / 16)))
    return reward

def RewardLevel(level):
    if level[0][0] == "A":
        return 1
    if level[0][0] == "B":
        return 5
    if level[0][0] == "C":
        return 10
    if level[0][0] == "D":
        return 25
    if level[0][0] == "E":
        return 40
    if level[0][0] == "F":
        return 0
    if level[0][0] == "G":
        return 10
    if level[0][0] == "H":
        return 20
    if level[0][0] == "I":
        return 30
    if level[0][0] == "J":
        return 50
    if level[0][0] == "K":
        return 75
    if level[0][0] == "L":
        return 100

def chestReward(chest):
    if chest.type == "small":
        reward = random.randint(1,500)
    elif chest.type == "large":
        reward = random.randint(333,1000)

    if reward <= 50:
        print("mimic")
    elif reward <= 225:
        #Small coins
        coins1.append(coin((chest.rect.x / 16,(chest.rect.y - 48) / 16),"bronze",10))
    elif reward <= 325:
        #Medium coins
        coins1.append(coin((chest.rect.x / 16,(chest.rect.y - 48) / 16),"silver",20))
    elif reward <= 400:
        #Large coins
        coins1.append(coin((chest.rect.x / 16,(chest.rect.y - 48) / 16),"gold",30))
    elif reward <= 650:
        #Bad weapon
        weapons1.append(weapons((chest.rect.x,chest.rect.y - 48,20,20),RandomWeapon(1,30),(chest.rect.x / 16,(chest.rect.y - 48) / 16)))
    elif reward <= 800:
        #Average weapon
        weapons1.append(weapons((chest.rect.x,chest.rect.y - 48,20,20),RandomWeapon(5,45),(chest.rect.x / 16,(chest.rect.y - 48) / 16)))
    elif reward <= 950:
        #Good weapon
        weapons1.append(weapons((chest.rect.x,chest.rect.y - 48,20,20),RandomWeapon(30,56),(chest.rect.x / 16,(chest.rect.y - 48) / 16)))
    elif reward <= 1000:
        #Amazing weapon
        weapons1.append(weapons((chest.rect.x,chest.rect.y - 48,20,20),RandomWeapon(45,65),(chest.rect.x / 16,(chest.rect.y - 48) / 16)))

def Parried():
    for e in enemy1:
        for b in e.bulletList1:
            if player1.weapon.hitbox.colliderect(b.newRect):
                e.bulletList1.remove(b)
                return 500
    return 2000

def RandomWeapon(minLevel,maxLevel):
    reward = random.randint(minLevel,maxLevel)
    if reward < 5:
        return "sword"
    elif reward < 10:
        return "dagger"
    elif reward < 20:
        return "swiftSword"
    elif reward < 30:
        return "falconBlade"
    elif reward < 37:
        return "copperEdge"
    elif reward < 45:
        return "royalRapier"
    elif reward < 52:
        return "jesterKnife"
    elif reward < 57:
        return "cobaltGreatsword"
    elif reward < 61:
        return "explosiveEdge"
    elif reward <= 65:
        return "holySword"
    else:
        return("holySword")

def NextLevel():
    global gameManager,player1,enemy1,key1,coins1,traps1,weapons1,walls,chests,chestKeys,currentRoom,currentFloor,map,map2,map3,minimap,minimap,minimap3,rewardBool,NPCList
    if gameManager.level == 1:

        x = 0
        for row in minimap2:
            minimap[x] = row
            x += 1
        
        y = 0
        for row in map2:
            map[y] = row
            y += 1
        
        gameManager.level += 1

    elif gameManager.level == 2:

        x = 0
        for row in minimap3:
            minimap[x] = row
            x += 1
        
        y = 0
        for row in map3:
            map[y] = row
            y += 1
        
        gameManager.level += 1
    
    currentRoom = startCurrentRoom
    currentFloor = startCurrentFloor

    enemy1 = createEnemies(map[currentFloor][currentRoom],9)
    for e in enemy1:
        e.images()
    key1 = createKey(map[currentFloor][currentRoom],9)
    coins1 = createCoins(map[currentFloor][currentRoom],9)
    traps1 = createTraps(map[currentFloor][currentRoom],9)
    weapons1 = createWeapons(map[currentFloor][currentRoom],9)
    walls = createWalls(map[currentFloor][currentRoom],9)
    chests = createChests(map[currentFloor][currentRoom])
    NPCList = []
    chestKeys = []
    rewardBool = False
    gameManager.resetting = True

def Coins():
    global coinWait, currentCoinSprite, coinPickupImage
    if len(coins1) != 0:
        for c in coins1:
            c.pickUp(player1.rect)
            if c.pickedUp:
                coins1.remove(c)
                player1.money += c.value
            
            elif not c.pickedUp and c.type == "bronze":
                if py.time.get_ticks() > coinWait + 100:
                    currentCoinSprite += 1
                    coinWait = py.time.get_ticks()
            
                coinPickupImage = bronze_coin_images[currentCoinSprite]
                screen.blit(coinPickupImage,c.rect)

                if currentCoinSprite >= 3:
                    currentCoinSprite = 0
            
            elif not c.pickedUp and c.type == "silver":
                if py.time.get_ticks() > coinWait + 100:
                    currentCoinSprite += 1
                    coinWait = py.time.get_ticks()
            
                coinPickupImage = silver_coin_images[currentCoinSprite]
                screen.blit(coinPickupImage,c.rect)

                if currentCoinSprite >= 3:
                    currentCoinSprite = 0
            
            elif not c.pickedUp and c.type == "gold":
                if py.time.get_ticks() > coinWait + 100:
                    currentCoinSprite += 1
                    coinWait = py.time.get_ticks()
            
                coinPickupImage = gold_coin_images[currentCoinSprite]
                screen.blit(coinPickupImage,c.rect)

                if currentCoinSprite >= 3:
                    currentCoinSprite = 0
 
def Parry():
    if py.mouse.get_pressed() == (0,0,1) and py.time.get_ticks() > player1.lastParried + player1.parryCooldown:
        player1.isParrying = True
        player1.parrySuccessBool = True
        player1.lastParried = py.time.get_ticks()
        player1.parryCooldown = Parried()

def WeaponPickup():
    for w in weapons1:
        w.images()
        w.weapon_type()
        screen.blit(w.image,w.pickupRect)
        for n in NPCList:
            if w.pickupRect.colliderect(n.product1Rect) and n.purchased1:
                w.purchased = True
            if w.pickupRect.colliderect(n.product2Rect) and n.purchased2:
                w.purchased = True
            if w.pickupRect.colliderect(n.product3Rect) and n.purchased3:
                w.purchased = True
    
    for w in weapons1:
        if py.time.get_ticks() > w.switchTimer + 200 and keys[py.K_g] and w.purchased:
            if player1.rect.colliderect(w.pickupRect):
                player1.oldWeapon = player1.weapon
                player1.weapon.pickedUp = False
                w.pickedUp = True
                w.switchTimer = py.time.get_ticks()
                player1.changeWeapon = True
        if w.pickedUp:
            player1.weapon = w
            weapons1.remove(w)

def EnemyHitstun():
    # Allows the enemies to hit the players
    for e in enemy1:
        if py.time.get_ticks() > e.hitstunAnimationTimer + player1.weapon.attackSpeed * 5:
            e.hitstunAnimation = False

def PlayerText():
    global player1MoneyAmount, player1ScoreAmount, player1Money, player1Score
    player1MoneyAmount = str(player1.money)
    player1ScoreAmount = str(player1.score) 
    player1Money = myFont.render((player1MoneyAmount),True,(255,255,255))
    player1Score = myFont.render((player1ScoreAmount),True,(255,255,255))
    screen.blit(player1Money,(32,684))
    screen.blit(player1Score,(1169,684))
 
def PlayerEmptyRoomSpeed():
    if len(enemy1) != 0:
        player1.speed = player1.normalSpeed
    else:
        player1.speed = player1.tempSpeed

def PlayerWeaponDirection():
    if not player1.isAttacking:
        playerVector = py.math.Vector2(player1.rect.x, player1.rect.y)
        mouseVector = py.math.Vector2(py.mouse.get_pos()[0],py.mouse.get_pos()[1])
        playerLook(playerVector,mouseVector)

def BossDefeated():
    global p1ShopUpdateBool, p1ShopUpdateTimer, p1ShopUpdate
    if len(enemy1) == 0 and (map[currentFloor][currentRoom])[0][0] == "F":
        if p1ShopUpdateBool:
            p1ShopUpdate = True
            p1ShopUpdateTimer = py.time.get_ticks()
            p1ShopUpdateBool = False

        portal = Portal((618,328,64,64))
        if portal.open:
            screen.blit(portal.image,portal.rect)
            if keys[py.K_SPACE] and player1.rect.colliderect(portal.rect):
                NextLevel()
                portal.open = False

def ChestOpen():
    global chestWait, currentChestSprite, chestPickupImage, currentBigChestSprite
    for chest in chests:
        if player1.rect.colliderect(chest.rect) and keys[py.K_SPACE] and not chest.opened and player1.keys >= 1 and not chest.opening:
                chest.opening = True
                player1.keys -= 1

        if chest.type == "small":
            if not chest.opening and not chest.opened:
                screen.blit(chest_images[0],chest.rect)

            elif chest.opening:
                if py.time.get_ticks() > chestWait + 100:
                    currentChestSprite += 1
                    chestWait = py.time.get_ticks()
            
                chestPickupImage = chest_images[currentChestSprite]
                screen.blit(chestPickupImage,chest.rect)

                if currentChestSprite >= 3:
                    chest.opening = False
                    chest.opened = True

            elif chest.opened:
                screen.blit(chest_images[3],chest.rect)
                currentChestSprite = 0
        
        elif chest.type == "large":
            if not chest.opening and not chest.opened:
                screen.blit(big_chest_images[0],chest.rect)

            elif chest.opening:
                if py.time.get_ticks() > chestWait + 100:
                    currentChestSprite += 1
                    chestWait = py.time.get_ticks()
            
                chestPickupImage = big_chest_images[currentBigChestSprite]
                screen.blit(chestPickupImage,chest.rect)

                if currentBigChestSprite >= 3:
                    chest.opening = False
                    chest.opened = True

            elif chest.opened:
                screen.blit(big_chest_images[3],chest.rect)
                currentBigChestSprite = 0
        
        if chest.opened and not chest.openedBool:
            chestReward(chest)
            chest.openedBool = True
            chests.remove(chest)

def KeyPickup():
    for k in chestKeys:
        if not k.pickedUp:
            screen.blit(gold_key,k.rect)
        if player1.rect.colliderect(k.rect):
            k.pickedUp = True
            player1.keys += 1
            chestKeys.remove(k)

def NPCDrawAndBuy():
    for n in NPCList:
        screen.blit(n.shopImage,n.rect)
        
        if not n.productBool:
            n.Products()
            
        if not n.productBool:
            for p in n.productList:
                if p[0] == "weapon":
                    weapons1.append(weapons((n.rect.x + p[1] * 32,n.rect.y + 80,20,20),RandomWeapon(20,62),((n.rect.x + p[1] * 32) / 16,(n.rect.y + 80) / 16)))
                if p[0] == "potion":
                    weapons1.append(weapons((n.rect.x + p[1] * 32,n.rect.y + 80,20,20),RandomWeapon(20,62),((n.rect.x + p[1] * 32) / 16,(n.rect.y + 80) / 16)))
                if p[0] == "key":
                    chestKeys.append(chestKey((n.rect.x + p[1] * 32,n.rect.y + 80,20,20)))
            for w in weapons1:
                w.purchased = False
            n.productBool = True
        
        if player1.rect.colliderect(n.product1Rect) and keys[py.K_SPACE]:
            if n.cost <= player1.money and not n.purchased1:
                player1.money -= n.cost
                n.purchased1 = True

        elif player1.rect.colliderect(n.product2Rect) and keys[py.K_SPACE]:
            if n.cost <= player1.money and not n.purchased2:
                player1.money -= n.cost
                n.purchased2 = True

        elif player1.rect.colliderect(n.product3Rect) and keys[py.K_SPACE]:
            if n.cost <= player1.money and not n.purchased3:
                player1.money -= n.cost
                n.purchased3 = True

def Dead():
    screen.fill(red)
    player1.finalScore = "Score: " + str(player1.score)
    player1.finalMoney = "Money: " + str(player1.money)
    player1Score = myFont.render((player1.finalScore),True,(255,255,255))
    player1Money = myFont.render((player1.finalMoney),True,(255,255,255))
    screen.blit(player1Score,(display_width * 0.6,display_height * 0.5))
    screen.blit(player1Money,(display_width * 0.6,display_height * 0.4))
    image = py.transform.scale(player1.damagedSprites[0],(200,200))
    screen.blit(image,(display_width * 0.35,display_height * 0.3))
    deadButton = Button(py.Rect(16,600,300,100),screen)
    py.draw.rect(screen,black,deadButton.rect)
    if py.mouse.get_pressed() == (1,0,0):
        mouseRect = py.Rect(py.mouse.get_pos()[0],py.mouse.get_pos()[1],1,1)
        if mouseRect.colliderect(deadButton.rect):
            gameManager.menu = "main"
    

#Game Loop
game_running = True
while game_running:
    keys = py.key.get_pressed()
    #keep loop running at the right speed
    clock.tick(FPS)
    #Process input (events)
    for event in py.event.get():
        #check for closing window
        if event.type == py.QUIT:
            game_running = False

    #update
    keys = py.key.get_pressed()
    screen.fill(back)
    gameManager.LoadScreen(screen)
    
    if gameManager.menu == "main":
        mainMenu()
    
    if gameManager.menu == "preGame":
        preGameLobby()

    if gameManager.menu == "game" and not gameManager.resetting:

        # Draws all the walls onto the screen
        showWalls()

        # Allows th player to move while not being attacked or attacking
        PlayerMove()  

        # Animates the players movement,idle etc.
        playerAnimate()

        # Allows the player to attack while not being damaged
        PlayerAttack()

        # Creates the effects of some unique weapons like the explosion
        PlayerAttackEffects()     

        # Draws the weapon the player is using
        WeaponDraw()

        # Calculates where to put the images of the sword depending on where the cursor is
        PlayerWeaponDirection()

        #moves and draws enemies
        EnemyDraw()

        # Makes the enemy invincible briefly after they have been hit
        EnemyHitstun()

        # Draws the enemies and animates their movement and attacks
        EnemyAnimate()

        # Allows enemies to fire at player
        EnemyFire()

        # Draws the enemy bullets and moves them 
        BulletMove()

        # Removes bullets if they it a player or a wall
        BulletCollide()  

        # Draws the players health on the healthbar and allows the player to die if they go below 0 health
        PlayerHealth()

        # Allows the player to change room
        ChangeRoom()

        # Clears all bullets and walls from a room and the creates the new room to give illusion of changing room
        UpdateRoom()

        # Shows the minimap on the screen keeping track of the player's current room and room they are going into
        miniMap()

        # Draws the traps in a level and allows them to fire
        TrapsFire()

        # Moves the projectiles from traps like the arrow and fireball
        MoveTrapProjectiles()

        # Animates the coin and gives the money to the player if they pick it up
        Coins()

        # Allows the player to open chests and get rewards from them
        ChestOpen()
        
        # Adds to key total when a key is picked up and shows thee key on scren
        KeyPickup()

        # Draws the weapons on the floor
        WeaponPickup()

        # Allows the player to parry projectiles
        Parry()

        # Draws the text onto the screen for the player's coins and score
        PlayerText()

        # Speeds up player when travelling through an empty room to make it less tedious
        PlayerEmptyRoomSpeed()

        # Creates the NPC stand and aaa to the next level when the boss has been defeated
        BossDefeated()

        # Gives the player 2 abilities on the 'e' and 'q' key depending on the class they decided on at the beggining of the game
        classAbilities()
    
        # Draws the NPC stand and items and allows the player to purchase them
        NPCDrawAndBuy()

        if keys[py.K_l]:
            enemy1 = []

    elif gameManager.menu == "game" and gameManager.resetting:
        gameManager.resetting = False

    if gameManager.menu == "win":
        screen.fill(green)

    if gameManager.menu == "lose":
        Dead()

    if gameManager.menu == "leaderboard":
        screen.fill(back)
        f = open("leaderboard.txt","r")
        fCount = 0
        for line in f:
            if fCount <= 8:
                print(fCount)
                entry = str(line)
                entryString = entry.split(",")
                entryName = entryString[0]
                entryScore = (entryString[1])[:-1]
                fString =str(fCount + 1) + ":" + str(entryName) + str(entryScore)
                leaderboardList[fCount] = myFont.render(fString,True,(255,255,255))
                fCount += 1
        for i in range(10):
            screen.blit(leaderboardList[i],(100,i*50))


    #*after* drawing everything, flip the display
    py.display.flip()

py.quit()