from pickle import FALSE
import pygame as py
from pygame.locals import *
import math

class block():
    def __init__(self,grid,index):
        self.grid = grid
        self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,16,16)
        self.index = index
        self.doorOpening = False
        self.doorOpened = False
        self.currentDoorSprite = 0
        self.doorImage = py.image.load("door1.png").convert_alpha()
