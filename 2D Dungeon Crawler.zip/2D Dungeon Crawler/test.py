import random
import pygame as py

py.init()
screen = py.display.set_mode((1280,720), py.FULLSCREEN)

# The amount of rooms i want the level to have
roomsLeft = 6

# A 2D array of the levels layout
map = [["","",""],
       ["","",""],
       ["","",""]]

# decides which of the first 3 room to start in
startRoom = random.randint(0,2)

# Sets the floor vairable to be at the bottom and the room to be the start room
currentFloor = 2
currentRoom = startRoom

# Places a # where the starting room is
map[currentFloor][currentRoom] = "#"

# Makes the loop repeat 5 times to make a total of 6 rooms
for i in range(5):
       # Sets the boolean next to be false which determines when to go to the next iteration of the for loop in case something can't happen e.g. tries to go right when it can't
       next = False
       # Starting if statements to check if the current room is a bad position so it has to jump from right to left (vice versa) or down 
       if (currentFloor == 0 and currentRoom == 0) and map[currentFloor][currentRoom + 1] == "#" and i < 5:
              currentRoom = 2
              if map[currentFloor][currentRoom] != "#":
                     map[currentFloor][currentRoom] = "#"
              else:
                     currentFloor += 1
                     currentRoom = 0
                     map[currentFloor][currentRoom] = "#"
              next = True
       elif (currentFloor == 0 and currentRoom == 2) and map[currentFloor][currentRoom - 1] == "#" and i < 5:
              currentRoom = 0
              if map[currentFloor][currentRoom] != "#":
                     map[currentFloor][currentRoom] = "#"
              else:
                     currentFloor += 1
                     currentRoom = 2
                     map[currentFloor][currentRoom] = "#"
              next = True
       # Generates the direction of the snake if there was no error above
       while not next:
              roomDirection = random.randint(1,3)
              if roomDirection == 1:
                     if currentRoom != 0:
                            if map[currentFloor][currentRoom-1] != "#":
                                   currentRoom -= 1
                                   next = True
              elif roomDirection == 2:
                     if currentFloor != 0:
                            if map[currentFloor-1][currentRoom] != "#":
                                   currentFloor -= 1
                                   next = True
              elif roomDirection == 3:
                     if currentRoom != 2 :
                            if map[currentFloor][currentRoom+1] != "#":
                                   currentRoom += 1
                                   next = True
              map[currentFloor][currentRoom] = "#"

# Prints the map
print(map[0],"\n",map[1],"\n",map[2])

mapXS = 0
mapYS = 0
for row in map:
       for column in row:
              if column == "#":
                     print("This is room",mapXS,mapYS)
              mapXS += 1
       mapYS += 1
       mapXS = 0

g = True
while g:
       keys = py.key.get_pressed()
    #keep loop running at the right speed
    #Process input (events)
       for event in py.event.get():
        #check for closing window
              if event.type == py.QUIT:
                     game_running = False
       
       if keys[py.K_ESCAPE]:
              game_running = False
            
       screen.fill((255,255,255))
       mapX = 0
       mapY = 0
       for row in map:
              for column in row:
                     if column == "#":
                            py.draw.rect(screen,((255,0,0)),py.Rect(mapX*48,mapY*48,32,32))
                     mapX += 1
              mapY += 1
              mapX = 0

       py.display.flip()
py.quit()
