import pygame

class button():
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def printPos(self):
        print(self.x)

button1 = button(100,200)

button1.printPos()
