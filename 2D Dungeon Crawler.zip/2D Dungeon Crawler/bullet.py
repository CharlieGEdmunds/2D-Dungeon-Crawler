from cmath import cos, pi
from turtle import speed
import pygame as py
from pygame.locals import *
import math

class bullet():
    def __init__(self,start_pos_x,start_pos_y,direction_x,direction_y,speed,size,enemy,number,angle):
        self.size = size
        self.playerSize = 20
        self.startX = start_pos_x
        self.startY = start_pos_y
        self.dirX = direction_x
        self.dirY = direction_y
        self.speed = speed
        self.damage = 10
        self.startPos = py.math.Vector2(self.startX + self.playerSize / 2 - self.size / 2,self.startY + self.playerSize / 2 - self.size / 2)
        self.endPos = py.math.Vector2(self.dirX + self.playerSize / 2 - self.size / 2,self.dirY + self.playerSize / 2 - self.size / 2)
        self.archerEndPos = py.math.Vector2(self.dirX,self.dirY)
        self.newPosition = py.math.Vector2(self.startX + self.playerSize / 2 - self.size / 2,self.startY + self.playerSize / 2 - self.size / 2)
        self.rect = py.Rect(enemy.x,enemy.y,self.size,self.size)
        self.newRect = py.Rect(self.startX,self.startY,size,size)
        
        self.angle1 = 0
        self.angle2 = 90
        self.number = number
        self.creationTime = py.time.get_ticks()
        self.multiShotBool = False
        if angle == 720:
            self.multiShotBool = True
        self.newRectBool = False
        self.bulletCollided = False
        self.boss3Angle = 0
        self.boss3InnerCircleDist = 50
        self.boss3OuterCircleDist = 100
        if self.number == 2:
            self.boss3Angle = (pi * 2) / 3
        if self.number == 3:
            self.boss3Angle = (pi * 4) / 3
        if self.number == 5:
            self.boss3Angle = (pi * 2) / 3
        if self.number == 6:
            self.boss3Angle = (pi * 4) / 3
        self.boss4Angle = angle
    
    def fire(self):
        self.direction = self.startPos - self.endPos
        if self.direction[0] != 0 or self.direction[1] != 0:
            velocity = self.direction.normalize() * self.speed
        else:
            velocity = py.math.Vector2(0,0)

        self.newPosition -= velocity
        self.newRect = py.Rect(self.newPosition[0],self.newPosition[1],self.size,self.size)
        self.rect.topleft = self.newPosition

    def archerFire(self):
        if self.number == 1 and self.multiShotBool:
            self.archerEndPos -= (100,100)
            self.multiShotBool = False
        elif self.number == 2 and self.multiShotBool:
            self.archerEndPos -= (-100,100)
            self.multiShotBool = False

        self.direction = self.startPos - self.archerEndPos

        if self.direction[0] != 0 or self.direction[1] != 0:
            velocity = self.direction.normalize() * self.speed
        else:
            velocity = py.math.Vector2(0,0)

        self.newPosition -= velocity
        self.newRect = py.Rect(self.newPosition[0],self.newPosition[1],self.size,self.size)
        self.rect.topleft = self.newPosition
    
    def curvedFire(self,surface,image):
        self.direction = self.startPos - self.endPos
        self.diameter = math.sqrt(self.direction[0] ** 2 + self.direction[1] ** 2)
        self.centre = self.direction / 2


        surface.blit(image,self.rect)
    
    def bossFire1(self):
        self.direction = self.startPos - self.endPos
        if self.direction[0] != 0 or self.direction[1] != 0:
            velocity = self.direction.normalize() * self.speed
        else:
            velocity = py.math.Vector2(0,0)

        self.newPosition -= velocity
        self.newRect = py.Rect(self.newPosition[0],self.newPosition[1],self.size,self.size)
        self.rect.topleft = self.newPosition
    
    def bossFire2(self):
        if self.number == 1:
            self.newRect.x += self.speed
            self.newRect.y += self.speed
        if self.number == 2:
            self.newRect.x += self.speed
            self.newRect.y -= self.speed
        if self.number == 3:
            self.newRect.x -= self.speed
            self.newRect.y -= self.speed
        if self.number == 4:
            self.newRect.x -= self.speed
            self.newRect.y += self.speed
    
    def bossFire3(self):
        if self.number <= 3:
            self.newRect.x = self.rect.centerx + 8 + self.boss3OuterCircleDist * math.cos(self.boss3Angle)
            self.newRect.y = self.rect.centery + 8 + self.boss3OuterCircleDist * math.sin(self.boss3Angle)
            self.boss3Angle += (math.pi / 60)
        elif self.number <= 6:
            self.newRect.x = self.rect.centerx + 8 + self.boss3InnerCircleDist * math.cos(self.boss3Angle) 
            self.newRect.y = self.rect.centery + 8 + self.boss3InnerCircleDist * math.sin(self.boss3Angle) * -1
            self.boss3Angle += (math.pi / 60)
    
    def bossFire4(self):
        self.newRect.x += self.speed * math.cos(self.boss4Angle)
        self.newRect.y += self.speed * math.sin(self.boss4Angle)