from turtle import up
import pygame as py
from pygame.locals import *

class weapons():
    def __init__(self,hitbox,weaponType,grid):
        self.hitbox = py.Rect(hitbox)
        self.weapon = weaponType
        self.pickupRect = py.Rect(grid[0]*16,grid[1]*16,16,16)
        self.image = py.image.load("sword.png")

        self.switchCooldown = 500
        self.switchTimer = 0
        self.pickedUp = False
        self.speed = 0
        self.explosionDamage = 0
        self.infExplosion = False
        self.infKnockback = False
        self.knockback = 0
        self.infHeal = False
        self.healAmount = 0
        self.critChance = 0
        self.infCrit = False
        self.purchased = True

    def images(self):
        self.swordImage = py.image.load("sword.png")
        self.daggerImage = py.image.load("dagger.png")
        self.swiftSwordImage = py.image.load("swiftSword.png")
        self.copperEdgeImage = py.image.load("copperEdge.png")
        self.falconBladeImage = py.image.load("falconBlade.png")
        self.explosiveEdgeImage = py.image.load("explosiveEdge.png")
        self.cobaltGreatswordImage = py.image.load("cobaltGreatsword.png")
        self.holySwordImage = py.image.load("holySword.png")
        self.royalRapierImage = py.image.load("royalRapier.png")
        self.jesterKnifeImage = py.image.load("jesterKnife.png")

    def weapon_type(self):
        if self.weapon == "sword":
            self.image = self.swordImage
            self.damage = 10
            self.attackSpeed = 83
            self.speed = 0
            self.armourPen = 0
            self.knockback = 8
        elif self.weapon == "dagger":
            self.image = self.daggerImage
            self.damage = 6
            self.attackSpeed = 50
            self.speed = 0
            self.armourPen = 0.25
            self.knockback = 5
        elif self.weapon == "swiftSword":
            self.image = self.swiftSwordImage
            self.damage = 10
            self.attackSpeed = 75
            self.speed = 0.5
            self.armourPen = 0.1
        elif self.weapon == "copperEdge":
            self.image = self.copperEdgeImage
            self.damage = 15
            self.attackSpeed = 100
            self.speed = 0
            self.armourPen = 0.05
        elif self.weapon == "falconBlade":
            self.image = self.falconBladeImage
            self.damage = 8
            self.attackSpeed = 75
            self.speed = 0.25
            self.armourPen = 0.3
        elif self.weapon == "explosiveEdge":
            self.image = self.explosiveEdgeImage
            self.damage = 12
            self.attackSpeed = 115
            self.speed = -0.25
            self.armourPen = 0.05
            self.infExplosion = True
            self.explosionDamage = 25
        elif self.weapon == "cobaltGreatsword":
            self.image = self.cobaltGreatswordImage
            self.damage = 20
            self.attackSpeed = 130
            self.speed = -0.5
            self.armourPen = 0.1
            self.infKnockback = True
            self.knockback = 32
        elif self.weapon == "holySword":
            self.image = self.holySwordImage
            self.damage = 10
            self.attackSpeed = 90
            self.speed = 0
            self.armourPen = 0.025
            self.infHeal = True
            self.healAmount = 0.4
        elif self.weapon == "royalRapier":
            self.image = self.royalRapierImage
            self.damage = 7.5
            self.attackSpeed = 80
            self.speed = 0
            self.armourPen = 0.5
        elif self.weapon == "jesterKnife":
            self.image = self.jesterKnifeImage
            self.damage = 6
            self.attackSpeed = 50
            self.speed = 0.25
            self.armourPen = 0.1
            self.infCrit = True
            self.critChance = 0.2

    def set_pos(self,pos):
        self.pickupRect = py.Rect(pos)