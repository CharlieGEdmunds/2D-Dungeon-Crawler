import pygame as py

wall_1 = py.image.load("wall_1.png")
wall_1 = py.transform.scale(wall_1,(32,32))