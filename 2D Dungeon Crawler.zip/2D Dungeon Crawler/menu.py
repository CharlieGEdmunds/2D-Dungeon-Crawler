import pygame as py
from pygame.locals import *

screen = py.display.set_mode((1280,720),py.FULLSCREEN)

class menu():
    def __init__(self,menu):
        self.menu = menu
        self.rect = (0,0,1280,720)

    def images(self):
        self.backgroundImage = py.image.load("main_menu.png")
    
    def LoadScreen(self):
        if self.menu == "main":
            screen.blit(self.backgroundImage,self.rect)