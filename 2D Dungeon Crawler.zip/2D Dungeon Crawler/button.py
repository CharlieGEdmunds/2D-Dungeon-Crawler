import pygame as py

class Button():
    def __init__(self,rect,screen):
        self.rect = rect
        self.screen = screen
    
    def loadButton(self,image):
        py.draw.rect(self.screen,(255,255,255),self.rect)
        image = py.transform.scale(image,(96,96))
        self.screen.blit(image,self.rect)
