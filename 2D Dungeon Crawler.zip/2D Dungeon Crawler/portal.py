import pygame as py
from pygame.locals import *

class Portal():
    def __init__(self,rect):
        self.rect = rect
        self.open = True
        self.image = py.image.load("portalImage1.png")