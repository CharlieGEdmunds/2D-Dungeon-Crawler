import pygame as py
import random as r
from pygame.locals import *
from weapon import *

class NPCs():
    def __init__(self,rect,NPCtype):
        self.rect = rect
        self.NPCtype = NPCtype
        self.productList = []
        if self.NPCtype == "Vendor":
            self.shopImage = py.image.load("shop1.png")
        else:
            self.shopImage = py.image.load("shop2.png")
        
        self.productBool = False
        self.cost = 10

        self.product1Rect = py.Rect(self.rect.x,self.rect.y + 80,20,20)
        self.product2Rect = py.Rect(self.rect.x + 32,self.rect.y + 80,20,20)
        self.product3Rect = py.Rect(self.rect.x + 64,self.rect.y + 80,20,20)
        self.purchased1 = False
        self.purchased2 = False
        self.purchased3 = False
    
    def Products(self):
        for i in range(3):
            product = r.randint(1,3)
            if product == 1:
                productType = ["weapon", i]
                self.productList.append(productType)
            elif product == 2:
                productType = ["potion", i]
                self.productList.append(productType)
            elif product == 3:
                productType = ["key", i]
                self.productList.append(productType)