import pygame as py
from pygame.locals import *

class Chest():
    def __init__(self,grid,type):
        self.grid = grid
        self.rect = py.Rect(self.grid[0],self.grid[1],16,16)
        self.type = type
        self.opening = False
        self.opened = False
        self.openedBool = False
    
