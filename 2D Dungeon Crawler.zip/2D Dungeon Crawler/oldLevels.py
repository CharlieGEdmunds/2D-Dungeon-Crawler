from ast import Div, List
from queue import Empty
import pygame as py
from pygame.locals import *
from block import *
from player import *
from enemy import *
from key import *
from coin import *
from trap import *
from weapon import *
import random

level00 = [
    "A#############################??################################",
    "#                                                              #",
    "#                                                              #",
    "#                             333                              #",
    "#                             333                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                              ££££££                          #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "?                                                              ?",
    "?                                                              ?",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                      0      J R H G                          #",
    "#                                                              #",
    "#                      1     E F D C S                         #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "#                                                              #",
    "##############################??################################",
    ]

level05 = [
    "A##############??###############",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#              9               #",
    "#                              #",
    "?                              ?",
    "?                              ?",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#              1               #",
    "#                              #",
    "###############??###############",
    ]

level04 = [
    "###############??###############",
    "#                              #",
    "# ## ##               ### ###  #",
    "# #   #      #        #     #  #",
    "#           ###       #     #  #",
    "# #   #      #                 #",
    "# ## ##               #     #  #",
    "#                     #     #  #",
    "# #   #               ### ###  #",
    "# #   #      #                 #",
    "# ## ##     #                  #",
    "# ## ##                        #",
    "#                     ####     #",
    "#  ## ##       ##     #        #",
    "#  ## ##      ##      #        #",
    "?  #   #     ##       #        ?",
    "?  #   #    ##                 ?",
    "#                              #",
    "# ## ##  ####      #           #",
    "# #####            #           #",
    "#  ###   ####      #           #",
    "# #####  ####      #           #",
    "# ## ##                        #",
    "#                              #",
    "#        ####          ##      #",
    "#        ####          ##      #",
    "#        ####        ######    #",
    "#                    ######    #",
    "#                      ##      #",
    "#              1       ##      #",
    "#                              #",
    "###############??###############"
    ]

level01 = [
    "A##############??###############",
    "#         *%^      ^%*         #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#    ####       $      ####    #",
    "#    ####              ####    #",
    "#    ####     ####     ####    #",
    "#    ####     ####     ####    #",
    "#                              #",
    "#                              #",
    "#              33              #",
    "#              3               #",
    "#                              #",
    "#    ####    ######    ####    #",
    "?    ####    #@@@@#    ####    ?",
    "?    ####    #@£E@#    ####    ?",
    "#    ####    #@@@@#    ####    #",
    "#    ####    ##&&##    ####    #",
    "#     ^^      *  *      %%     #",
    "#                              #",
    "#      33              3       #",
    "#                              #",
    "#                              #",
    "#    ####              ####    #",
    "#    ####              ####    #",
    "#    ####              ####    #",
    "#    ####              ####    #",
    "#                              #",
    "#              1               #",
    "#                              #",
    "###############??###############"
    ]

level02 = [
    "###############??###############",
    "#%%%%%%%%%%%%%    %%%%%%%%%%%%%#",
    "#                              #",
    "#                              #",
    "#              ##              #",
    "#              ##              #",
    "#              ##              #",
    "#        ##    ##    ##        #",
    "#        **    ##    **        #",
    "#              ##              #",
    "#              ##              #",
    "#              **              #",
    "#                              #",
    "#     ####            ####     #",
    "#      ^^              ^^      #",
    "?                              ?",
    "?              ##              ?",
    "#              ##              #",
    "#              ^^              #",
    "#  ##    ##          ##    ##  #",
    "#  **    ^^          ^^    **  #",
    "#              ##              #",
    "#####          ##          #####",
    "#%%%%          ^^          %%%%#",
    "#       ####        ####       #",
    "#       ^^^^        ^^^^       #",
    "#              ##              #",
    "#              **              #",
    "#  ########          ########  #",
    "#  ********          ********  #",
    "#              1               #",
    "###############??###############"
    ]

level03 = [
    "A##############??###############",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#   ##########    ##########   #",
    "#   #                      #   #",
    "#   #          333         #   #",
    "#   #                      #   #",
    "#   #                      #   #",
    "?   #                      #   ?",
    "?   #                      #   ?",
    "# £ #                      # £ #",
    "#   #                      #   #",
    "##############    ##############",
    "#                              #",
    "#                         3    #",
    "#                              #",
    "###    #########################",
    "#                              #",
    "#  3                           #",
    "#                              #",
    "#########################    ###",
    "#                       *    * #",
    "#              1               #",
    "#                              #",
    "###############??###############",
    ]

boss = [
    "################################",
    "#                              #",
    "#              4               #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#                              #",
    "#               1              #",
    "#                              #",
    "################################",
    ]

### RANDOM MAP GENERATION ###

# The amount of rooms i want the level to have
roomsLeft = 6

# A 2D array of the levels layout
map = [["","",""],
       ["","",""],
       ["","",""]]

# decides which of the first 3 room to start in
startRoom = random.randint(0,2)

# Sets the floor vairable to be at the bottom and the room to be the start room
currentFloor = 2
currentRoom = startRoom

startCurrentFloor = 2
startCurrentRoom = startRoom

# Places a # where the starting room is
map[currentFloor][currentRoom] = "#"

levelsList = [level00,level01,level02,level03,level04]

levelNumber = 0


# Makes the loop repeat 5 times to make a total of 6 rooms
for i in levelsList:
    # Sets the boolean next to be false which determines when to go to the next iteration of the for loop in case something can't happen e.g. tries to go right when it can't
    next = False
    # Starting if statements to check if the current room is a bad position so it has to jump from right to left (vice versa) or down 
    if (currentFloor == 0 and currentRoom == 0) and map[currentFloor][currentRoom + 1] == List and i < 5:
            currentRoom = 2
            if map[currentFloor][currentRoom] != List:
                    map[currentFloor][currentRoom] = i
            else:
                    currentFloor += 1
                    currentRoom = 0
                    map[currentFloor][currentRoom] = i
            next = True
    elif (currentFloor == 0 and currentRoom == 2) and map[currentFloor][currentRoom - 1] == List and i < 5:
            currentRoom = 0
            if map[currentFloor][currentRoom] != List:
                    map[currentFloor][currentRoom] = i
            else:
                    currentFloor += 1
                    currentRoom = 2
                    map[currentFloor][currentRoom] = i
            next = True
    # Generates the direction of the snake if there was no error above
    while not next:
            roomDirection = random.randint(1,3)
            if roomDirection == 1:
                    if currentRoom != 0:
                        if map[currentFloor][currentRoom-1] != List:
                                currentRoom -= 1
                                next = True
            elif roomDirection == 2:
                    if currentFloor != 0:
                        if map[currentFloor-1][currentRoom] != List:
                                currentFloor -= 1
                                next = True
            elif roomDirection == 3:
                    if currentRoom != 2 :
                        if map[currentFloor][currentRoom+1] != List:
                                currentRoom += 1
                                next = True
            map[currentFloor][currentRoom] = i
    levelNumber += 1

currentRoom = startCurrentRoom
currentFloor = startCurrentFloor
print("HEllo")

def randomEnemy(roomPoints,roomEnemies):
    enemyList = []
    enemiesRemaining = roomEnemies - 1
    for i in range(roomEnemies - 1):
        tempEnemy = random.randint(1,roomPoints - enemiesRemaining)
        roomPoints -= tempEnemy
        enemyList.append(tempEnemy)
        enemiesRemaining -= 1
    tempEnemy = roomPoints
    enemyList.append(tempEnemy)
    return enemyList



def createPlayer(level,xpar):
    x = xpar
    player1 = True
    y = 3
    for row in level:
        for col in row:
            if col == "1" and player1:
                player_1 = player((x,y),0)
            x += 1
        x = xpar
        y += 1
    if player1:
        return player_1

def createEnemiesNumbers(level,xpar):
    x = xpar
    y = 3
    enemyNumber = 0
    roomPoints = 0
    enemies = []
    for row in level:
        for col in row:
            if col == "A" and x == xpar and y == 3:
                roomPoints = 10
            if col == "3":
                enemyNumber += 1
            x += 1
        x = xpar
        y += 1
    enemies = randomEnemy(roomPoints,enemyNumber)
    return enemies

def createEnemies(level,xpar,numbersList):
    x = xpar
    y = 3
    numberList = []
    count = 0
    for i in numbersList:
        numberList.append(i)
    enemies = []
    for row in level:
        for col in row:
            if col == "3":
                new_enemy = enemy((x,y),numberList[count])
                enemies.append(new_enemy)
                count += 1
            if col == "4":
                new_enemy = enemy((x,y),100)
                enemies.append(new_enemy)
            if col == "9":
                new_enemy = enemy((x,y),10)
                enemies.append(new_enemy)
            x += 1
        x = xpar
        y += 1
    x = xpar
    y = 3
    return enemies

def createKey(level,xpar):
    x = xpar
    y = 3
    key_1 = 0
    for row in level:
        for col in row:
            if col == "$":
                key_1 = key((x,y))
            x += 1
        x = xpar
        y += 1
    return key_1

def createCoins(level,xpar):
    x = xpar
    y = 3
    coins = []
    for row in level:
        for col in row:
            if col == "£":
                new_coin = coin((x,y),0,10)
                coins.append(new_coin)
            x += 1
        x = xpar
        y += 1
    return coins

def createTraps(level,xpar):
    x = xpar
    y = 3
    ypar = y
    traps = []
    for row in level:
        for col in row:
            if col == "#" and y != 42:
                if (level[y-ypar+1][x-xpar] == "%"):
                    new_trap = trap((x,y),0)
                    traps.append(new_trap)
                elif (level[y-ypar+1][x-xpar] == "^"):
                    new_trap = trap((x,y),1)
                    traps.append(new_trap)
                elif (level[y-ypar+1][x-xpar] == "*"):
                    new_trap = trap((x,y),2)
                    traps.append(new_trap)
            x += 1
        x = xpar
        y += 1
    return traps

def createWeapons(level,xpar):
    x = xpar
    y = 3
    weaponList = []
    for row in level:
        for col in row:
            if col == "D":
                new_weapon = weapons((x,y,20,20),"dagger",(x,y))
                weaponList.append(new_weapon)
            if col == "S":
                new_weapon = weapons((x,y,20,20),"swiftSword",(x,y))
                weaponList.append(new_weapon)
            if col == "C":
                new_weapon = weapons((x,y,20,20),"copperEdge",(x,y))
                weaponList.append(new_weapon)
            if col == "F":
                new_weapon = weapons((x,y,20,20),"falconBlade",(x,y))
                weaponList.append(new_weapon)
            if col == "E":
                new_weapon = weapons((x,y,20,20),"explosiveEdge",(x,y))
                weaponList.append(new_weapon)
            if col == "G":
                new_weapon = weapons((x,y,20,20),"cobaltGreatsword",(x,y))
                weaponList.append(new_weapon)
            if col == "H":
                new_weapon = weapons((x,y,20,20),"holySword",(x,y))
                weaponList.append(new_weapon)
            if col == "R":
                new_weapon = weapons((x,y,20,20),"royalRapier",(x,y))
                weaponList.append(new_weapon)
            if col == "J":
                new_weapon = weapons((x,y,20,20),"jesterKnife",(x,y))
                weaponList.append(new_weapon)
            
            x += 1
        x = xpar
        y += 1
    return weaponList
