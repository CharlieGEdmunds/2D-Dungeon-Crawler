import pygame as py
from pygame.locals import *
from weapon import *

class player():
    def __init__(self,grid,money):
        self.size = 20
        self.grid = grid
        self.speed = 2
        self.rect = py.Rect(self.grid[0]*16,self.grid[1]*16,self.size,self.size)
        self.isMoving = False
        self.isDamaged = False
        self.isAttacking = False
        self.isParrying = False
        self.weapon = weapons((self.rect.x,self.rect.y - 20,20,20),"sword",(self.rect.x,self.rect.y))

        self.NextLevel = False
        self.normalSpeed = self.speed
        self.tempSpeed = 4
        self.money = money
        self.score = 0
        self.healthAmount = 100
        self.healthDecorationRect = py.Rect(32,16,63,17)
        self.healthImageRect = py.Rect(46,16,63,17)
        self.healthLostRect = py.Rect(94,21,1,7)
        self.healthLost = 0
        self.healthRatio = 63/100
        self.hitstun = 0
        self.dead = False
        self.facing = "up"
        self.weapon.pickedUp = True
        self.parryCooldown = 500
        self.lastParried = 0
        self.parrySuccess = False
        self.parrySuccessBool = False
        self.idleImage = py.image.load("ninjaIdle1.png")
        self.currentIdleTimer = 0
        self.currentMoveTimer = 0
        self.currentDamagedTimer = 0
        self.currentAttackTimer = 0
        self.currentParryTimer = 0
        self.attackSpeed = 100
        self.weaponSwitch = False
        self.changeWeapon = False
        self.oldWeapon = None
        self.creExplosion = False
        self.explosionCooldown = -10000
        self.explosionTimer = 0
        self.explosionRect = py.Rect(self.weapon.hitbox.x - 16, self.weapon.hitbox.y - 16, 48,48)
        self.creKnockback = False
        self.creHeal = False
        self.crit = False
        self.level = 0
        self.character = "menu"
        self.doubleDamage = False
        self.ability1Timer = 0
        self.ability2Timer = 0
        self.keys = 0
        self.bossDefeated = False
        self.character = "ninja"
        self.bulletList = []
        self.lastFired = 0
        self.attackSpeedBoost = False
        self.multiShot = False
        self.invisible = False
        self.hookedCooldown = 0
        self.hitstunTimer = 400
        self.stunnedTimer = 0
        self.finalScore = 0
        self.finalMoney = 0
    
    def initialise(self):
        if self.character == "ninja":
            self.speed = 2
            self.ability1Cooldown = 4500
            self.ability2Cooldown = 15000
        elif self.character == "archer":
            self.speed = 1.8
            self.ability1Cooldown = 7000
            self.ability2Cooldown = 3000


    def move(self,x,y,collision):
        new_rect_x = self.rect.move(x,0)
        new_rect_y = self.rect.move(0,y)
        collisionCheckX = False
        collisionCheckY = False

        for c in collision:
            if new_rect_x.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23 and (c.index != 34 or not c.doorOpened):
                collisionCheckX = True
            elif new_rect_x.colliderect(c.rect) and c.index == "door":
                self.NextLevel = True
                
        
        if collisionCheckX == False:
            self.rect.x = new_rect_x.x

        for c in collision:
            if new_rect_y.colliderect(c.rect) and c.index != "door" and c.index != "floor" and c.index != 1 and c.index != 23 and (c.index != 34 or not c.doorOpened):
                collisionCheckY = True
            elif new_rect_y.colliderect(c.rect) and c.index == 34:
                if True:
                    pass
                self.NextLevel = True
                
        
        if collisionCheckY == False:
            self.rect.y = new_rect_y.y
    
    def health(self,screen,healthImage,healthDecoration):
        screen.blit(healthDecoration,self.healthDecorationRect)
        screen.blit(healthImage,self.healthImageRect)
        self.healthLostRect.w = self.healthLost
        py.draw.rect(screen,(26,26,26),self.healthLostRect)
        if self.healthAmount <= 0:
            self.dead = True
    
    def hit(self,damage):
        if py.time.get_ticks() > self.hitstun + self.hitstunTimer:
            self.isDamaged = True
            self.healthAmount -= damage
            self.hitstun = py.time.get_ticks()
            self.healthLost = (100 - self.healthAmount) * 0.49
            self.healthLostRect.x = 96 - self.healthLost
        
    def attack(self):
        self.weapon.weapon_type()
    
    def change_weapon(self):
        self.speed += self.weapon.speed - self.oldWeapon.speed
        self.changeWeapon = False
    
    def hooked(self,direction):
        if direction == "left":
            self.rect.x += 20
        elif direction == "right":
            self.rect.x -= 20
    
    def stunned(self,time):
        self.stunnedTimer += time

    def images(self):
        self.weapon.images()

        if self.character == "ninja":
            self.idleSprites = []
            self.idleSprites.append(py.image.load("ninjaIdle1.png"))
            self.idleSprites.append(py.image.load("ninjaIdle2.png"))
            self.idleSprites.append(py.image.load("ninjaIdle3.png"))
            self.idleSprites.append(py.image.load("ninjaIdle4.png"))
            self.currentIdleSprite = 0

            self.moveSprites = []
            self.moveSprites.append(py.image.load("ninjaMove1.png"))
            self.moveSprites.append(py.image.load("ninjaMove2.png"))
            self.moveSprites.append(py.image.load("ninjaMove3.png"))
            self.moveSprites.append(py.image.load("ninjaMove4.png"))
            self.moveSprites.append(py.image.load("ninjaMove5.png"))
            self.moveSprites.append(py.image.load("ninjaMove6.png"))
            self.moveSprites.append(py.image.load("ninjaMove7.png"))
            self.moveSprites.append(py.image.load("ninjaMove8.png"))
            self.currentMoveSprite = 0

            self.damagedSprites = []
            self.damagedSprites.append(py.image.load("ninjaDamaged1.png"))
            self.damagedSprites.append(py.image.load("ninjaDamaged2.png"))
            self.damagedSprites.append(py.image.load("ninjaDamaged3.png"))
            self.damagedSprites.append(py.image.load("ninjaDamaged4.png"))
            self.currentDamagedSprite = 0

            self.attackSprites = []
            self.attackSprites.append(py.image.load("ninjaAttack1.png"))
            self.attackSprites.append(py.image.load("ninjaAttack2.png"))
            self.attackSprites.append(py.image.load("ninjaAttack3.png"))
            self.attackSprites.append(py.image.load("ninjaAttack4.png"))
            self.attackSprites.append(py.image.load("ninjaAttack5.png"))
            self.currentAttackSprite = 0

            self.parrySprites = []
            self.parrySprites.append(py.image.load("ninjaAttack2.png"))
            self.parrySprites.append(py.image.load("ninjaAttack5.png"))
            self.currentParrySprite = 0
        
        if self.character == "archer":
            self.idleSprites = []
            self.idleSprites.append(py.image.load("archerIdle1.png"))
            self.idleSprites.append(py.image.load("archerIdle2.png"))
            self.idleSprites.append(py.image.load("archerIdle3.png"))
            self.idleSprites.append(py.image.load("archerIdle4.png"))
            self.currentIdleSprite = 0

            self.moveSprites = []
            self.moveSprites.append(py.image.load("archerMove1.png"))
            self.moveSprites.append(py.image.load("archerMove2.png"))
            self.moveSprites.append(py.image.load("archerMove3.png"))
            self.moveSprites.append(py.image.load("archerMove4.png"))
            self.moveSprites.append(py.image.load("archerMove5.png"))
            self.moveSprites.append(py.image.load("archerMove6.png"))
            self.moveSprites.append(py.image.load("archerMove7.png"))
            self.moveSprites.append(py.image.load("archerMove8.png"))
            self.currentMoveSprite = 0

            self.damagedSprites = []
            self.damagedSprites.append(py.image.load("archerDamaged1.png"))
            self.damagedSprites.append(py.image.load("archerDamaged2.png"))
            self.damagedSprites.append(py.image.load("archerDamaged3.png"))
            self.damagedSprites.append(py.image.load("archerDamaged4.png"))
            self.currentDamagedSprite = 0

            self.attackSprites = []
            self.attackSprites.append(py.image.load("archerAttack1.png"))
            self.attackSprites.append(py.image.load("archerAttack2.png"))
            self.attackSprites.append(py.image.load("archerAttack3.png"))
            self.attackSprites.append(py.image.load("archerAttack4.png"))
            self.attackSprites.append(py.image.load("archerAttack5.png"))
            self.attackSprites.append(py.image.load("archerAttack6.png"))
            self.attackSprites.append(py.image.load("archerAttack7.png"))
            self.attackSprites.append(py.image.load("archerAttack8.png"))
            self.currentAttackSprite = 0

            self.parrySprites = []
            self.parrySprites.append(py.image.load("ninjaAttack2.png"))
            self.parrySprites.append(py.image.load("ninjaAttack5.png"))
            self.currentParrySprite = 0
    
    def updateIdle(self):
        if py.time.get_ticks() > self.currentIdleTimer + 100:
            self.currentIdleSprite += 1
            if self.currentIdleSprite >= len(self.idleSprites):
                self.currentIdleSprite = 0
            
            self.idleImage = self.idleSprites[self.currentIdleSprite]
            if self.facing == "left":
                self.idleImage = py.transform.flip(self.idleImage,1,0)
            self.currentIdleTimer = py.time.get_ticks()
    
    def updateMove(self):
        if py.time.get_ticks() > self.currentMoveTimer + 100:
            self.currentMoveSprite += 1
            if self.currentMoveSprite >= len(self.moveSprites):
                self.currentMoveSprite = 0
            
            self.moveImage = self.moveSprites[self.currentMoveSprite]
            if self.facing == "left":
                self.moveImage = py.transform.flip(self.moveImage,1,0)
            self.currentMoveTimer = py.time.get_ticks()
    
    def updateDamaged(self):
        if py.time.get_ticks() > self.currentDamagedTimer + (50 + self.stunnedTimer / 5):
            self.currentDamagedSprite += 1
            if self.currentDamagedSprite >= len(self.damagedSprites):
                self.currentDamagedSprite = 0
                self.isDamaged = False
                self.stunnedTimer = 0
            
            self.damagedImage = self.damagedSprites[self.currentDamagedSprite]
            if self.facing == "left":
                self.damagedImage = py.transform.flip(self.damagedImage,1,0)
            self.currentDamagedTimer = py.time.get_ticks()
    
    def updateAttack(self):
        if py.time.get_ticks() > self.currentAttackTimer + self.weapon.attackSpeed:
            self.currentAttackSprite += 1
            if self.currentAttackSprite >= len(self.attackSprites):
                self.currentAttackSprite = 0
                self.isAttacking = False
            
            self.attackImage = self.attackSprites[self.currentAttackSprite]
            if self.facing == "left":
                self.attackImage = py.transform.flip(self.attackImage,1,0)
            self.currentAttackTimer = py.time.get_ticks()
    
    def updateParry(self):
        if py.time.get_ticks() > self.currentParryTimer + self.weapon.attackSpeed:
            self.currentParrySprite += 1
            if self.currentParrySprite >= len(self.parrySprites):
                self.currentParrySprite = 0
                self.isParrying = False
            
            self.parryImage = self.parrySprites[self.currentParrySprite]
            if self.facing == "left":
                self.parryImage = py.transform.flip(self.parryImage,1,0)
            self.currentParryTimer = py.time.get_ticks()
